package com.campulse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampulseNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
