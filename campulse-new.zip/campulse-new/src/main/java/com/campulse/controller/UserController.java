package com.campulse.controller;

import com.campulse.EmailService;
import com.campulse.entity.User.User;
import com.campulse.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
// this is for prople login, signup and forget password only
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;
    @Autowired
    EmailService emailService;
    //localhost:8081/user/signup for signup
    //data need to be given - {username:"2300031542",password:"31542",email:"2300031542@kluniversity.in",fullName:"Thiruveedula Chandra Sekhar"}
    @PostMapping("/signup")
    public String signup(@RequestBody(required = false) User user) {
        if (user == null) {
            return "Invalid signup request. User data is missing.";
        }
        return userService.signup(user);
    }
    //localhost:8081/user/login for login
    //{username:"2300031542",password:"31542"}
    @PostMapping("/login")
    public String login(@RequestBody(required = false) User user) {
        if (user == null) {
            return "Invalid login request. User data is missing.";
        }
        return userService.login(user);
    }
    //localhost:8081/user/forget-password/2300031542 to get password to the mail
    @PostMapping("/forget-password/{username}")
    public String forgetPassword(@PathVariable String username) {
        try {
            User user = userService.getUserByUsername(username);

            if (user == null || user.getEmail() == null) {
                return "User not found or email not available.";
            }

            String subject = "Your Campulse Account Password";
            String body = "<!DOCTYPE html>" +
                    "<html>" +
                    "<head><meta charset='UTF-8'></head>" +
                    "<body style='font-family: Arial, sans-serif;'>" +
                    "<h2>Campulse – Password Recovery</h2>" +
                    "<p>Hello <b>" + safeString(user.getFullName()) + "</b>,</p>" +
                    "<p>Your account password is:</p>" +
                    "<div style='background:#f4f4f4; padding:10px; border:1px solid #ddd; border-radius:5px;'>" +
                    "<b>" + safeString(user.getPassword()) + "</b>" +
                    "</div>" +
                    "<p>Please keep it safe</p>" +
                    "<br><p>Regards,<br>Campulse Team</p>" +
                    "</body></html>";

            emailService.sendHtmlEmail(user.getEmail(), subject, body);
            return "Password has been sent to your registered email.";

        } catch (Exception e) {
            return "Error during password recovery: " + e.getMessage();
        }
    }

    // Utility to avoid nulls in email content
    private String safeString(Object value) {
        return (value == null) ? "" : value.toString();
    }

    private String safeList(List<String> list) {
        if (list == null || list.isEmpty()) {
            return "";
        }
        return String.join(", ", list);
    }
}
