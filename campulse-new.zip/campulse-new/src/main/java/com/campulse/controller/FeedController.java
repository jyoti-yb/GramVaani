package com.campulse.controller;

import com.campulse.EmailService;
import com.campulse.entity.Feed.Feed;
import com.campulse.entity.Feed.FeedComments;
import com.campulse.service.FeedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/feed")
public class FeedController {

    @Autowired
    FeedService feedService;


    @PostMapping("/feed")
    public String uploadFeed(@RequestBody(required = false) Feed feed) {
        if (feed == null) {
            return "Invalid feed request. Feed data is missing.";
        }
        return feedService.uploadFeed(feed);
    }

    // Update feed
    @PutMapping("/feed")
    public String updateFeed(@RequestBody(required = false) Feed feed) {
        if (feed == null) {
            return "Invalid update request. Feed data is missing.";
        }
        return feedService.updateFeed(feed);
    }

    // Delete feed
    @DeleteMapping("/feed/{id}")
    public String deleteFeed(@PathVariable Long id) {
        if (id == null) {
            return "Invalid feed id.";
        }
        return feedService.deleteFeed(id);
    }

    // Get all feeds
    @GetMapping("/feeds")
    public List<Feed> getAllFeeds() {
        try {
            return feedService.getFeed();
        } catch (Exception e) {
            System.err.println("Error fetching feeds: " + e.getMessage());
            return Collections.emptyList();
        }
    }

    // Get feeds by username
    @GetMapping("/feeds/{username}")
    public List<Feed> getFeedsByUsername(@PathVariable String username) {
        if (username == null || username.trim().isEmpty()) {
            return Collections.emptyList();
        }
        try {
            return feedService.getFeedByUsername(username);
        } catch (Exception e) {
            System.err.println("Error fetching feeds by username: " + e.getMessage());
            return Collections.emptyList();
        }
    }

    @Autowired
    private FeedService commentsService;

    // Add comment
    @PostMapping("/comments")
    public String addComment(@RequestBody FeedComments comment) {
        return commentsService.addComment(comment);
    }

    // Update comment
    @PutMapping("/comments")
    public String updateComment(@RequestBody FeedComments comment) {
        return commentsService.updateComment(comment);
    }

    // Delete comment
    @DeleteMapping("/comments/{num}")
    public String deleteComment(@PathVariable Long num) {
        return commentsService.deleteComment(num);
    }

    // Get comments by feedId
    @GetMapping("/comments/{feedId}")
    public List<FeedComments> getCommentsByFeedId(@PathVariable Long feedId) {
        try {
            return commentsService.getCommentsByFeedId(feedId);
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }
}
