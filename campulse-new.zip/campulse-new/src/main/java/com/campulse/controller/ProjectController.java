package com.campulse.controller;


import com.campulse.DTO.ProfileDTO;
import com.campulse.DTO.ProjectApplyDTO;
import com.campulse.DTO.ProjectUploadDTO;
import com.campulse.EmailService;
import com.campulse.entity.ChatGroup;
import com.campulse.entity.Project.MiscellaneousProject;
import com.campulse.entity.Project.MiscellaneousProjectApply;
import com.campulse.entity.Project.ProjectApply;
import com.campulse.entity.Project.Validation.Ideas;
import com.campulse.entity.Project.Validation.ValidateComments;
import com.campulse.entity.User.User;
import com.campulse.service.ProfileService;
import com.campulse.service.ProjectService;
import com.campulse.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/project")
public class ProjectController {

    @Autowired
    UserService userService;
    @Autowired
    EmailService emailService;
    @Autowired
    ProfileService profileService;
    @Autowired
    ProjectService projectService;
    @PostMapping("/project")
    public String uploadProject(@RequestBody(required = false) ProjectUploadDTO projectUploadDTO) {
        if (projectUploadDTO == null) {
            return "Invalid project upload request. Data is missing.";
        }
        return projectService.uploadProject(projectUploadDTO);
    }

    @DeleteMapping("/project/{id}")
    public String deleteProject(@PathVariable Long id) {
        if (id == null) {
            return "Invalid project ID.";
        }
        return projectService.deleteProject(id);
    }

    @GetMapping("/projects")
    public List<ProjectUploadDTO> getProjects() {
        try {
            return projectService.getAllProjects();
        } catch (Exception e) {
            System.err.println("Error fetching projects: " + e.getMessage());
            return Collections.emptyList();
        }
    }
    @PostMapping("/project/apply")
    public String applyProject(@RequestBody(required = false) ProjectApplyDTO projectApplyDTO) {
        if (projectApplyDTO == null) {
            return "Invalid project apply request. Data is missing.";
        }
        String response = projectService.applyProject(projectApplyDTO);

        try {
            // Recipient (project owner)
            User recipient = userService.getUserByUsername(projectApplyDTO.getUsername());

            // Applicant (myUserName → Profile)
            ProfileDTO applicantProfile = profileService.getProfileByUsername(projectApplyDTO.getMyUsername());

            if (recipient != null && recipient.getEmail() != null && applicantProfile != null) {
                String to = recipient.getEmail();
                String subject = "New Application for Your Project: " + safeString(projectApplyDTO.getProjectName());

                String body = "<!DOCTYPE html>" +
                        "<html>" +
                        "<head>" +
                        "  <meta charset='UTF-8'>" +
                        "  <style>" +
                        "    body { font-family: Arial, sans-serif; margin:0; padding:0; background: linear-gradient(135deg, #6a11cb, #2575fc); }" +
                        "    .container { max-width: 600px; margin: 40px auto; background: #ffffff; border-radius: 12px; box-shadow: 0 6px 18px rgba(0,0,0,0.15); overflow: hidden; }" +
                        "    .header { background: linear-gradient(135deg, #6a11cb, #2575fc); padding: 20px; text-align: center; color: white; }" +
                        "    .header h1 { margin: 0; font-size: 22px; font-weight: bold; }" +
                        "    .content { padding: 25px; color: #333; line-height: 1.6; }" +
                        "    .details { background: #f5f5ff; border-left: 4px solid #6a11cb; padding: 15px; border-radius: 8px; margin: 20px 0; }" +
                        "    .details p { margin: 6px 0; }" +
                        "    .btn { display: inline-block; padding: 12px 20px; background: #6a11cb; color: #fff; text-decoration: none; font-weight: bold; border-radius: 6px; margin-top: 20px; }" +
                        "    .footer { background: #f9f9f9; text-align: center; padding: 15px; font-size: 13px; color: #777; }" +
                        "    .footer a { color: #6a11cb; text-decoration: none; }" +
                        "  </style>" +
                        "</head>" +
                        "<body>" +
                        "  <div class='container'>" +
                        "    <div class='header'>" +
                        "      <h1>Campulse – Project Application</h1>" +
                        "    </div>" +
                        "    <div class='content'>" +
                        "      <p>Hello <b>" + safeString(recipient.getFullName()) + "</b>,</p>" +
                        "      <p>You have received a new application for your project.</p>" +
                        "      <div class='details'>" +
                        "        <p><b>Project:</b> " + safeString(projectApplyDTO.getProjectName()) + "</p>" +
                        "        <p><b>Description:</b> " + safeString(projectApplyDTO.getDescription()) + "</p>" +
                        "        <p><b>Technologies:</b> " + safeList(projectApplyDTO.getTechnologies()) + "</p>" +
                        "      </div>" +
                        "      <h3>Applicant Details</h3>" +
                        "      <div class='details'>" +
                        "        <p><b>Name:</b> " + safeString(applicantProfile.getFullName()) + "</p>" +
                        "        <p><b>Username:</b> " + safeString(applicantProfile.getUsername()) + "</p>" +
                        "        <p><b>Branch:</b> " + safeString(applicantProfile.getBranch()) + "</p>" +
                        "        <p><b>Skills:</b> " + safeList(applicantProfile.getSkills()) + "</p>" +
                        "        <p><b>GitHub:</b> <a href='" + safeString(applicantProfile.getGithubLink()) + "'>" + safeString(applicantProfile.getGithubLink()) + "</a></p>" +
                        "        <p><b>LinkedIn:</b> <a href='" + safeString(applicantProfile.getLinkedinLink()) + "'>" + safeString(applicantProfile.getLinkedinLink()) + "</a></p>" +
                        "      </div>" +
                        "    </div>" +
                        "    <div class='footer'>" +
                        "      Regards,<br>Campulse Team<br>" +
                        "    </div>" +
                        "  </div>" +
                        "</body>" +
                        "</html>";

                emailService.sendHtmlEmail(to, subject, body);
            }
        } catch (Exception e) {
            System.err.println("Error sending project application email: " + e.getMessage());
        }

        return response;
    }

    @GetMapping("/project/applied/{myUserName}")
    public List<ProjectApply> getAllProjectApply(@PathVariable String myUserName) {
        try {
            return projectService.getAllProjectApply(myUserName);
        } catch (Exception e) {
            System.err.println("Error fetching project applications: " + e.getMessage());
            return Collections.emptyList();
        }
    }

    @GetMapping("/project/my-applications/{userName}")
    public List<ProjectApply> getAllProjectApplied(@PathVariable String userName) {
        try {
            return projectService.getAllProjectApplied(userName);
        } catch (Exception e) {
            System.err.println("Error fetching project applications: " + e.getMessage());
            return Collections.emptyList();
        }
    }

    @PostMapping("/project/accept")
    public String acceptApplicant(@RequestBody(required = false) ProjectApplyDTO projectApplyDTO) {
        if (projectApplyDTO == null) {
            return "Invalid request. Data is missing.";
        }

        String response = projectService.acceptApplicant(projectApplyDTO);

        try {
            // ✅ Fetch applicant email
            User applicantUser = userService.getUserByUsername(projectApplyDTO.getMyUsername());

            if (applicantUser != null && applicantUser.getEmail() != null) {
                String subject = "You Have Been Accepted to Project: " + safeString(projectApplyDTO.getProjectName());
                String body = "<h2>Congratulations!</h2>"
                        + "<p>Hello " + safeString(applicantUser.getFullName()) + ",</p>"
                        + "<p>You have been accepted into the project <b>" + safeString(projectApplyDTO.getProjectName()) + "</b>.</p>"
                        + "<p>Project Description: " + safeString(projectApplyDTO.getDescription()) + "</p>"
                        + "<br><p>Regards,<br>Campulse Team</p>";

                emailService.sendHtmlEmail(applicantUser.getEmail(), subject, body);
            }
        } catch (Exception e) {
            System.err.println("Error sending acceptance email: " + e.getMessage());
        }

        return response;
    }

    // Utility to avoid nulls in email content
    private String safeString(Object value) {
        return (value == null) ? "" : value.toString();
    }

    private String safeList(List<String> list) {
        if (list == null || list.isEmpty()) {
            return "";
        }
        return String.join(", ", list);
    }
    @Autowired
    private ProjectService validationService;

    // ---------------- IDEA ENDPOINTS ----------------
    @PostMapping("/idea")
    public String addIdea(@RequestBody(required = false) Ideas idea) {
        if (idea == null) return "Invalid request. Idea data missing.";
        return validationService.addIdea(idea);
    }

    @GetMapping("/ideas")
    public List<Ideas> getAllIdeas() {
        try {
            return validationService.getAllIdeas();
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    @GetMapping("/idea/{title}")
    public Ideas getIdea(@PathVariable String title) {
        return validationService.getIdeaByTitle(title);
    }

    @DeleteMapping("/idea/{title}")
    public String deleteIdea(@PathVariable String title) {
        return validationService.deleteIdea(title);
    }

    // ---------------- COMMENTS ENDPOINTS ----------------
    @PostMapping("/comment")
    public String addComment(@RequestBody(required = false) ValidateComments comment) {
        if (comment == null) return "Invalid request. Comment data missing.";
        return validationService.addComment(comment);
    }

    @GetMapping("/comments/{title}")
    public List<ValidateComments> getCommentsByTitle(@PathVariable String title) {
        try {
            return validationService.getCommentsByTitle(title);
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    @DeleteMapping("/comment/{id}")
    public String deleteComment(@PathVariable Long id) {
        return validationService.deleteComment(id);
    }
    // ---------------- MISCELLANEOUS PROJECT ENDPOINTS ----------------
    @PostMapping("/misc/project")
    public String createMiscProject(@RequestBody(required = false) MiscellaneousProject project) {
        if (project == null) return "Invalid request. Project data missing.";
        try {
            projectService.createMiscellaneousProject(project);
            return "Miscellaneous project created successfully.";
        } catch (Exception e) {
            return "Failed to create miscellaneous project: " + e.getMessage();
        }
    }

    @GetMapping("/misc/projects")
    public List<MiscellaneousProject> getAllMiscProjects() {
        try {
            return projectService.getAllMiscellaneousProjects();
        } catch (Exception e) {
            System.err.println("Error fetching miscellaneous projects: " + e.getMessage());
            return Collections.emptyList();
        }
    }

    @PostMapping("/misc/project/apply")
    public String applyMiscProject(@RequestBody(required = false) MiscellaneousProjectApply application) {
        if (application == null) return "Invalid request. Application data missing.";
        try {
            projectService.applyToMiscellaneousProject(application);
            return "Applied to miscellaneous project successfully.";
        } catch (Exception e) {
            return "Failed to apply: " + e.getMessage();
        }
    }

    @GetMapping("/misc/project/applications/{teamName}")
    public List<MiscellaneousProjectApply> getMiscProjectApplications(@PathVariable String teamName) {
        try {
            return projectService.getApplicationsForMiscellaneousTeam(teamName);
        } catch (Exception e) {
            System.err.println("Error fetching applications: " + e.getMessage());
            return Collections.emptyList();
        }
    }

    @PostMapping("/misc/project/accept/{applicationId}")
    public String acceptMiscProjectApplicant(@PathVariable Long applicationId) {
        try {
            projectService.acceptMiscellaneousCandidate(applicationId);
            return "Applicant accepted successfully.";
        } catch (Exception e) {
            return "Failed to accept applicant: " + e.getMessage();
        }
    }

    // ---------------- DELETE MISCELLANEOUS PROJECT ----------------
    @DeleteMapping("/misc/project/{teamName}")
    public String deleteMiscProject(@PathVariable String teamName) {
        if (teamName == null || teamName.trim().isEmpty()) {
            return "Invalid team name.";
        }
        return projectService.deleteMiscellaneousProject(teamName);
    }


    @GetMapping("/group/members/{groupName}")
    public ResponseEntity<List<ChatGroup>> getGroupMembers(@PathVariable String groupName) {
        try {
            List<ChatGroup> members = projectService.getGroupMembers(groupName);
            if (members.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(members);
            }
            return ResponseEntity.ok(members);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

}
