package com.campulse.controller;

import com.campulse.DTO.ProfileDTO;
import com.campulse.service.ProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/profile")
public class ProfileController {
    @Autowired
    ProfileService profileService;
    //localhost:8081/profile to create profile
    //{
    //  "username": "2300031542",
    //  "fullName": "Thiruveedula Chandra Sekhar",
    //  "branch": "Computer Science and Engineering",
    //  "college": "KL University",
    //  "year": 3,
    //  "projects": [
    //    "Inventory Management System",
    //    "Medicine Reminder Machine",
    //    "Educational Support Prototype"
    //  ],
    //  "skills": [
    //    "C",
    //    "Core Java",
    //    "Data Structures and Algorithms",
    //    "Python"
    //  ],
    //  "interests": [
    //    "AI",
    //    "Web Development",
    //    "Problem Solving"
    //  ],
    //  "achievements": [
    //    "High School 100% score",
    //    "Intermediate 97.9%",
    //    "University CGPA 9.8"
    //  ],
    //  "bio": "Aspiring data engineer passionate about coding and solving logical problems.",
    //  "phone": "9491578736",
    //  "githubLink": "https://github.com/sekhar",
    //  "linkedinLink": "https://linkedin.com/in/sekhar"
    //}
    @PostMapping("/")
    public String createProfile(@RequestBody(required = false) ProfileDTO profileDTO) {
        if (profileDTO == null) {
            return "Invalid profile request. Profile data is missing.";
        }
        return profileService.createProfile(profileDTO);
    }
    //same upper url will work for updation also but mapping should be put mapping
    @PutMapping("/")
    public String updateProfile(@RequestBody(required = false) ProfileDTO profileDTO) {
        if (profileDTO == null) {
            return "Invalid update request. Profile data is missing.";
        }
        return profileService.updateProfile(profileDTO);
    }

    //to get the data of someone, use this url
    @GetMapping("/{username}")
    public ProfileDTO getProfile(@PathVariable String username) {
        if (username == null || username.trim().isEmpty()) {
            return null;
        }
        return profileService.getProfileByUsername(username);
    }
}
