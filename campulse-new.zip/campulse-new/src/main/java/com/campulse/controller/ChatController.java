package com.campulse.controller;

import com.campulse.DTO.ChatMessage;
import com.campulse.service.ChatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ChatController {

    @Autowired
    private ChatService chatService;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    // WebSocket message endpoint
    @MessageMapping("/chat.sendMessage")
    public void sendMessage(ChatMessage message) {
        ChatMessage saved = chatService.saveMessage(message);

        // send to group-specific topic
        messagingTemplate.convertAndSend(
            "/topic/group/" + message.getGroupName(),
            saved
        );
    }


    // REST endpoint to fetch chat history of a group
    @GetMapping("/chat/{groupName}")
    public List<ChatMessage> getGroupMessages(@PathVariable String groupName) {
        return chatService.getMessages(groupName);
    }
}
