package com.campulse.entity.Project;

import jakarta.persistence.*;

@Entity
public class ProjectApply {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String title;

    private String applicant;
    private String teamLead;
    private String fullName; // team lead full name
    private String projectName;
    private String description;
    private boolean accept;

    private String category; // ✅ NEW FIELD

    // ---------- Constructors ----------
    public ProjectApply(){}

    public ProjectApply(String title, String applicant, String teamLead, String fullName,
                        String projectName, String description, boolean accept, String category) {
        this.title = (title != null) ? title : "";
        this.applicant = (applicant != null) ? applicant : "";
        this.teamLead = (teamLead != null) ? teamLead : "";
        this.fullName = (fullName != null) ? fullName : "";
        this.projectName = (projectName != null) ? projectName : "";
        this.description = (description != null) ? description : "";
        this.accept = accept;
        this.category = (category != null) ? category : "";
    }

    // ---------- Getters & Setters ----------
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = (title != null) ? title : ""; }

    public String getApplicant() { return applicant; }
    public void setApplicant(String applicant) { this.applicant = (applicant != null) ? applicant : ""; }

    public String getTeamLead() { return teamLead; }
    public void setTeamLead(String teamLead) { this.teamLead = (teamLead != null) ? teamLead : ""; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = (fullName != null) ? fullName : ""; }

    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = (projectName != null) ? projectName : ""; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = (description != null) ? description : ""; }

    public boolean getAccept() { return accept; }
    public void setAccept(boolean accept) { this.accept = accept; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = (category != null) ? category : ""; }

    @Override
    public String toString() {
        return "ProjectApply [id=" + id + ", title=" + title + ", applicant=" + applicant +
                ", teamLead=" + teamLead + ", fullName=" + fullName +
                ", projectName=" + projectName + ", description=" + description +
                ", accept=" + accept + ", category=" + category + "]";
    }
}
