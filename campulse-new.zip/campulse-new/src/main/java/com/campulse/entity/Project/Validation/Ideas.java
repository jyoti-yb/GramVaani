package com.campulse.entity.Project.Validation;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDate;

@Entity
public class Ideas {
    @Id
    private String title;
    private String teamLead;
    private String description;
    private String fullName;
    private LocalDate date;

    public Ideas() {}
    public Ideas(String title, String teamLead, String description, String fullName, LocalDate date){
        this.title = title;
        this.teamLead = teamLead;
        this.description = description;
        this.fullName = fullName;
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTeamLead() {
        return teamLead;
    }

    public void setTeamLead(String teamLead) {
        this.teamLead = teamLead;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Ideas{" +
                "title='" + title + '\'' +
                ", teamLead='" + teamLead + '\'' +
                ", description='" + description + '\'' +
                ", fullName='" + fullName + '\'' +
                ", date=" + date +
                '}';
    }
}
