package com.campulse.entity.Profile;

import jakarta.persistence.*;

@Entity
public class TeamFindApply {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String myUsername;
    private String username;
    private String fullName;
    private String branch;

    public TeamFindApply(){}
    // ---------- Getters & Setters ----------
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    public String getMyUsername() {
        return myUsername;
    }
    public void setMyUsername(String myUserName) {
        this.myUsername = (myUserName != null) ? myUserName : "";
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = (username != null) ? username : "";
    }

    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = (fullName != null) ? fullName : "";
    }

    public String getBranch() {
        return branch;
    }
    public void setBranch(String branch) {
        this.branch = (branch != null) ? branch : "";
    }

    @Override
    public String toString() {
        return "TeamFindApply [id=" + id + ", myUserName=" + myUsername +
                ", username=" + username + ", fullName=" + fullName +
                ", branch=" + branch + "]";
    }

}
