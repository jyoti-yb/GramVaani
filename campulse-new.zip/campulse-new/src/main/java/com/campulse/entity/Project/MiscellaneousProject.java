package com.campulse.entity.Project;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class MiscellaneousProject {
    @Id
    private String teamName;
    private String teamLead;
    private int maxSize;
    private int currentSize = 0;
    
    public MiscellaneousProject() {}
    public MiscellaneousProject(String teamName, String teamLead, int maxSize, int currentSize){
        this.teamName = teamName;
        this.teamLead = teamLead;
        this.maxSize = maxSize;
        this.currentSize = currentSize;
    }


    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getTeamLead() {
        return teamLead;
    }

    public void setTeamLead(String teamLead) {
        this.teamLead = teamLead;
    }

    public int getMaxSize() {
        return maxSize;
    }

    public void setMaxSize(int maxSize) {
        this.maxSize = maxSize;
    }

    public int getCurrentSize() {
        return currentSize;
    }

    public void setCurrentSize(int currentSize) {
        this.currentSize = currentSize;
    }

    @Override
    public String toString() {
        return "MiscellaneousProject{" +
                ", teamName='" + teamName + '\'' +
                ", teamLead='" + teamLead + '\'' +
                ", maxSize=" + maxSize +
                ", currentSize=" + currentSize +
                '}';
    }
}
