package com.campulse.entity.Profile;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Profile {
    @Id
    private String username;
    private String fullName;
    private String branch;
    private String college;
    private int year;
    private String bio;
    private String phone;
    private String githubLink;
    private String linkedinLink;

    // ---------- Constructors ----------
    public Profile() {
    }

    public Profile(String username, String fullName, String branch, String college, int year, String phone, String githubLink, String bio, String linkedinLink) {
        this.username = username;
        this.fullName = fullName;
        this.branch = branch;
        this.college = college;
        this.year = year;
        this.phone = phone;
        this.githubLink = githubLink;
        this.bio = bio;
        this.linkedinLink = linkedinLink;
    }

    // ---------- Getters & Setters ----------
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = (username != null) ? username : "";
    }

    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = (fullName != null) ? fullName : "";
    }

    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        this.year = year;
    }

    public String getBranch() {
        return branch;
    }
    public void setBranch(String branch) {
        this.branch = (branch != null) ? branch : "";
    }

    public String getCollege() {
        return college;
    }
    public void setCollege(String college) {
        this.college = (college != null) ? college : "";
    }

    public String getBio() {
        return bio;
    }
    public void setBio(String bio) {
        this.bio = (bio != null) ? bio : "";
    }

    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = (phone != null) ? phone : "";
    }

    public String getGithubLink() {
        return githubLink;
    }
    public void setGithubLink(String githubLink) {
        this.githubLink = (githubLink != null) ? githubLink : "";
    }

    public String getLinkedinLink() {
        return linkedinLink;
    }
    public void setLinkedinLink(String linkedinLink) {
        this.linkedinLink = (linkedinLink != null) ? linkedinLink : "";
    }
    // ---------- toString ----------
    @Override
    public String toString() {
        return "Profile [username=" + username + ", fullName=" + fullName + ", branch=" + branch +
                ", college=" + college + ", year=" + year +
                ", bio=" + bio + ", phone=" + phone + ", githubLink=" + githubLink +
                ", linkedinLink=" + linkedinLink + "]";
    }
}
