package com.campulse.entity.Project;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class MiscellaneousProjectApply {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String teamName;
    private String teamLead;
    private String applicant;
    private boolean accepted;
    public MiscellaneousProjectApply() {}
    public MiscellaneousProjectApply(String teamName, String teamLead, String applicant, boolean accepted){
        this.teamName = teamName;
        this.teamLead  =teamLead;
        this.applicant = applicant;
        this.accepted = accepted;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getTeamLead() {
        return teamLead;
    }

    public void setTeamLead(String teamLead) {
        this.teamLead = teamLead;
    }

    public String getApplicant() {
        return applicant;
    }

    public void setApplicant(String applicant) {
        this.applicant = applicant;
    }

    @Override
    public String toString() {
        return "MiscellaneousProjectApply{" +
                "id=" + id +
                ", teamName='" + teamName + '\'' +
                ", teamLead='" + teamLead + '\'' +
                ", applicant='" + applicant + '\'' +
                ", accepted=" + accepted +
                '}';
    }

    public boolean isAccepted() {
        return accepted;
    }

    public void setAccepted(boolean accepted) {
        this.accepted = accepted;
    }
}
