package com.campulse.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ChatGroup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String groupName;
    private String teamMate;
    public ChatGroup() {
    }
    public ChatGroup(String groupName, String teamMate){
        this.groupName = groupName;
        this.teamMate = teamMate;
    }

    public long getId() {
        return id;
    }

    @Override
    public String toString() {
        return "ChatGroup{" +
                "id=" + id +
                ", groupName='" + groupName + '\'' +
                ", teamMate='" + teamMate + '\'' +
                '}';
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getTeamMate() {
        return teamMate;
    }

    public void setTeamMate(String teamMate) {
        this.teamMate = teamMate;
    }
}
