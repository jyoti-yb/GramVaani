package com.campulse.entity.Feed;

import jakarta.persistence.*;

@Entity
public class FeedComments {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long num;

    @Column(nullable = false)
    private long feedId; // refers to Feed.id

    @Column(nullable = false, columnDefinition = "TEXT")
    private String comment;

    @Column(nullable = false)
    private String username; // user who made the comment

    public FeedComments() {}

    public FeedComments(long feedId, String comment, String username) {
        this.feedId = feedId;
        this.comment = comment;
        this.username = username;
    }

    public long getNum() { return num; }
    public void setNum(long num) { this.num = num; }

    public long getFeedId() { return feedId; }
    public void setFeedId(long feedId) { this.feedId = feedId; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    @Override
    public String toString() {
        return "FeedComments{" +
                "num=" + num +
                ", feedId=" + feedId +
                ", comment='" + comment + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}
