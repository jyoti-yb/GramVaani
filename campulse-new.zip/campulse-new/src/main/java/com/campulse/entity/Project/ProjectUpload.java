package com.campulse.entity.Project;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class ProjectUpload {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(unique = true)
    private String title;
    private String teamLead;
    private String fullName;
    private String description;
    private LocalDate date;
    private String category;

    private int maxTeamMembers; // maximum team members allowed
    private int currentTeamMembers = 0; // starts at 0 by default

    // ---------- Constructors ----------
    public ProjectUpload() {}

    public ProjectUpload(String title, String teamLead, String fullName, String description,
                         LocalDate date, int maxTeamMembers, String category) {
        this.title = (title != null) ? title : "";
        this.teamLead = (teamLead != null) ? teamLead : "";
        this.fullName = (fullName != null) ? fullName : "";
        this.description = (description != null) ? description : "";
        this.date = date;
        this.maxTeamMembers = maxTeamMembers;
        this.currentTeamMembers = 0;
        this.category = (category != null) ? category : "";
    }

    // ---------- Getters & Setters ----------
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = (category != null) ? category : ""; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = (title != null) ? title : ""; }

    public String getTeamLead() { return teamLead; }
    public void setTeamLead(String teamLead) { this.teamLead = (teamLead != null) ? teamLead : ""; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = (fullName != null) ? fullName : ""; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = (description != null) ? description : ""; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public int getMaxTeamMembers() { return maxTeamMembers; }
    public void setMaxTeamMembers(int maxTeamMembers) { this.maxTeamMembers = maxTeamMembers; }

    public int getCurrentTeamMembers() { return currentTeamMembers; }
    public void setCurrentTeamMembers(int currentTeamMembers) { this.currentTeamMembers = currentTeamMembers; }

    // ---------- toString ----------
    @Override
    public String toString() {
        return "ProjectUpload [id=" + id + ", title=" + title + ", teamLead=" + teamLead +
                ", fullName=" + fullName + ", description=" + description +
                ", date=" + date + ", maxTeamMembers=" + maxTeamMembers +
                ", currentTeamMembers=" + currentTeamMembers + ", category=" + category + "]";
    }
}
