package com.campulse.repo.Profile;

import com.campulse.entity.Profile.Profile;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ProfileRepo extends JpaRepository<Profile,String> {
    Optional<Profile> findByUsername(String username);
}
