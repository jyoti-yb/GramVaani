package com.campulse.repo.Profile;

import com.campulse.entity.Profile.ProfileAchievement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProfileAchievementRepo extends JpaRepository<ProfileAchievement, Long> {
    List<ProfileAchievement> findAllByUsername(String username);

    void deleteAllByUsername(String username);
}
