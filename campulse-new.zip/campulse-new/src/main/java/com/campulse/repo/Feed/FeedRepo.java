package com.campulse.repo.Feed;

import com.campulse.entity.Feed.Feed;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FeedRepo extends JpaRepository<Feed, Long> {
    List<Feed> findByUsername(String username);
}
