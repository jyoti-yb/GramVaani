package com.campulse.repo.Profile;

import com.campulse.entity.Profile.ProfileInterest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProfileInterestRepo extends JpaRepository<ProfileInterest, Long> {
    List<ProfileInterest> findAllByUsername(String username);

    void deleteAllByUsername(String username);
}
