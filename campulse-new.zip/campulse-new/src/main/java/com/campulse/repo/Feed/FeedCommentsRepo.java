package com.campulse.repo.Feed;

import com.campulse.entity.Feed.FeedComments;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FeedCommentsRepo extends JpaRepository<FeedComments, Long> {
    List<FeedComments> findByFeedId(Long feedId);
}
