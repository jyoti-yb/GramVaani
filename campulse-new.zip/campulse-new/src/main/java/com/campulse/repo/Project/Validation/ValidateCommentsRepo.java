package com.campulse.repo.Project.Validation;

import com.campulse.entity.Project.Validation.ValidateComments;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ValidateCommentsRepo extends JpaRepository<ValidateComments, Long> {
    List<ValidateComments> findAllByTitle(String title);
}
