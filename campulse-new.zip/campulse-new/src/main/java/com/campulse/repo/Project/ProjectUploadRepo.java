package com.campulse.repo.Project;

import com.campulse.entity.Project.ProjectUpload;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ProjectUploadRepo extends JpaRepository<ProjectUpload, Long> {
    Optional<ProjectUpload> findByTitle(String projectName);
}
