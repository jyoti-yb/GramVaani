package com.campulse.repo.Project;

import com.campulse.entity.Project.ProjectApply;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProjectApplyRepo extends JpaRepository<ProjectApply, Long> {
    List<ProjectApply> findAllByApplicant(String myUsername);
    List<ProjectApply> findAllByTeamLead(String username);

    List<ProjectApply> findAllByProjectName(String title);
}
