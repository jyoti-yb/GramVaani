package com.campulse.repo.Project.Validation;

import com.campulse.entity.Project.Validation.Ideas;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IdeasRepo extends JpaRepository<Ideas, String> {
}
