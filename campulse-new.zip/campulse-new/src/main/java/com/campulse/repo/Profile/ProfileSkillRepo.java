package com.campulse.repo.Profile;

import com.campulse.entity.Profile.ProfileSkill;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProfileSkillRepo extends JpaRepository<ProfileSkill, Long> {
    List<ProfileSkill> findAllByUsername(String username);

    void deleteAllByUsername(String username);
}
