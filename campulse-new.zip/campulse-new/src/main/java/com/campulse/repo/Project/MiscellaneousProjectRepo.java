package com.campulse.repo.Project;

import com.campulse.entity.Project.MiscellaneousProject;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MiscellaneousProjectRepo extends JpaRepository<MiscellaneousProject, String> {
    MiscellaneousProject findByTeamName(String teamName);
}