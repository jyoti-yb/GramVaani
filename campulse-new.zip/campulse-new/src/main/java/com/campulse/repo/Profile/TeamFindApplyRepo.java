package com.campulse.repo.Profile;

import com.campulse.DTO.TeamMemberDTO;
import com.campulse.entity.Profile.TeamFindApply;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TeamFindApplyRepo extends JpaRepository<TeamFindApply, Long> {
    List<TeamFindApply> findAllByMyUsername(String myUsername);
}
