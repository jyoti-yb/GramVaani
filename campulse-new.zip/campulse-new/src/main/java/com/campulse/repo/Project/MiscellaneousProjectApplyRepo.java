package com.campulse.repo.Project;

import com.campulse.entity.Project.MiscellaneousProjectApply;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MiscellaneousProjectApplyRepo extends JpaRepository<MiscellaneousProjectApply, Long> {

    List<MiscellaneousProjectApply> findByTeamName(String teamName);
}