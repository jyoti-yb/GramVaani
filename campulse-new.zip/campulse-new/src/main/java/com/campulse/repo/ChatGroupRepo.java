package com.campulse.repo;

import com.campulse.entity.ChatGroup;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChatGroupRepo extends JpaRepository<ChatGroup,Long> {
    List<ChatGroup> findByGroupName(String groupName);
}
