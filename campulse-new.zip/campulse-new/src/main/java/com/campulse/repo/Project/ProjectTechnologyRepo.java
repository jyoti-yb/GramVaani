package com.campulse.repo.Project;
import java.util.List;
import com.campulse.entity.Project.ProjectTechnology;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectTechnologyRepo extends JpaRepository<ProjectTechnology, Long> {
    List<ProjectTechnology> findAllByTitle(String title);

    void deleteAllByTitle(String title);
}
