package com.campulse.repo.Profile;

import com.campulse.entity.Profile.ProfileProject;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProfileProjectRepo extends JpaRepository<ProfileProject, Long> {
    List<ProfileProject> findAllByUsername(String username);

    void deleteAllByUsername(String username);
}
