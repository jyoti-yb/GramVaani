package com.campulse.service;

import com.campulse.DTO.ChatMessage;
import com.campulse.entity.ChatMessageEntity;
import com.campulse.repo.ChatMessageRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ChatService {

    @Autowired
    private ChatMessageRepo chatMessageRepo;

    public ChatMessage saveMessage(ChatMessage msg) {
        ChatMessageEntity entity = new ChatMessageEntity(
                msg.getGroupName(),
                msg.getSender(),
                msg.getContent(),
                LocalDateTime.now(),
                msg.getMessageType()
        );
        chatMessageRepo.save(entity);

        msg.setTimestamp(entity.getTimestamp().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        return msg;
    }

    public List<ChatMessage> getMessages(String groupName) {
        return chatMessageRepo.findByGroupNameOrderByTimestampAsc(groupName)
                .stream()
                .map(e -> new ChatMessage(
                        e.getGroupName(),
                        e.getSender(),
                        e.getContent(),
                        e.getMessageType(),
                        e.getTimestamp().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                ))
                .collect(Collectors.toList());
    }
}
