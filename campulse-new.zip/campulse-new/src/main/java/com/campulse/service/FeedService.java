package com.campulse.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.campulse.entity.Feed.Feed;
import com.campulse.entity.Feed.FeedComments;
import com.campulse.repo.Feed.FeedCommentsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.campulse.repo.Feed.FeedRepo;

@Service
public class FeedService {

    @Autowired
    private FeedRepo feedRepo;

    public String uploadFeed(Feed feed) {
        if (feed == null) {
            return "Invalid request: feed is missing.";
        }
        if (isBlank(feed.getTitle()) && isBlank(feed.getDescription())) {
            return "Feed must have at least a title or description.";
        }
        try {
            Feed saved = feedRepo.save(feed);
            return "Message sent successfully. id=" + saved.getId();
        } catch (Exception e) {
            return "Failed to save feed: " + e.getMessage();
        }
    }

    public String deleteFeed(Long id) {
        if (id == null) {
            return "Invalid request: id is missing.";
        }
        try {
            if (!feedRepo.existsById(id)) {
                return "Feed with id " + id + " not found.";
            }
            feedRepo.deleteById(id);
            return "Deleted successfully.";
        } catch (Exception e) {
            return "Failed to delete feed: " + e.getMessage();
        }
    }

    public String updateFeed(Feed feed) {
        if (feed == null || feed.getId() == null) {
            return "Invalid request: feed or feed.id is missing.";
        }
        try {
            Optional<Feed> existing = feedRepo.findById(feed.getId());
            if (existing.isEmpty()) {
                return "Feed with id " + feed.getId() + " not found.";
            }
            Feed toSave = existing.get();
            if (!isBlank(feed.getTitle())) toSave.setTitle(feed.getTitle());
            if (!isBlank(feed.getDescription())) toSave.setDescription(feed.getDescription());
            if (!isBlank(feed.getUsername())) toSave.setUsername(feed.getUsername());

            feedRepo.save(toSave);
            return "Message updated successfully.";
        } catch (Exception e) {
            return "Failed to update feed: " + e.getMessage();
        }
    }

    public List<Feed> getFeed() {
        try {
            return feedRepo.findAll();
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    public List<Feed> getFeedByUsername(String username) {
        if (isBlank(username)) {
            return Collections.emptyList();
        }
        try {
            return feedRepo.findByUsername(username);
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }


    @Autowired
    private FeedCommentsRepo commentsRepo;

    // Create Comment
    public String addComment(FeedComments comment) {
        if (comment == null || comment.getFeedId() == 0 || comment.getComment() == null || comment.getComment().trim().isEmpty()) {
            return "Invalid comment request.";
        }
        try {
            commentsRepo.save(comment);
            return "Comment added successfully.";
        } catch (Exception e) {
            return "Failed to add comment: " + e.getMessage();
        }
    }

    // Update Comment
    public String updateComment(FeedComments comment) {
        if (comment == null || comment.getNum() == 0) {
            return "Invalid update request.";
        }
        try {
            Optional<FeedComments> existing = commentsRepo.findById(comment.getNum());
            if (existing.isEmpty()) {
                return "Comment not found.";
            }
            FeedComments toSave = existing.get();
            if (comment.getComment() != null && !comment.getComment().trim().isEmpty()) {
                toSave.setComment(comment.getComment());
            }
            commentsRepo.save(toSave);
            return "Comment updated successfully.";
        } catch (Exception e) {
            return "Failed to update comment: " + e.getMessage();
        }
    }

    // Delete Comment
    public String deleteComment(Long num) {
        if (num == null) return "Invalid comment id.";
        try {
            if (!commentsRepo.existsById(num)) return "Comment not found.";
            commentsRepo.deleteById(num);
            return "Comment deleted successfully.";
        } catch (Exception e) {
            return "Failed to delete comment: " + e.getMessage();
        }
    }

    // Get Comments for Feed
    public List<FeedComments> getCommentsByFeedId(Long feedId) {
        if (feedId == null) return Collections.emptyList();
        try {
            return commentsRepo.findByFeedId(feedId);
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }
}
