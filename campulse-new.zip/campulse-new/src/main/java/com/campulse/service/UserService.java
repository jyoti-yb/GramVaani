package com.campulse.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.campulse.entity.User.User;
import com.campulse.repo.UserRepo;

@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;

    // Signup
    public String signup(User user) {
        try {
            if (user == null || user.getUsername() == null || user.getUsername().trim().isEmpty()
                    || user.getEmail() == null || user.getEmail().trim().isEmpty()
                    || user.getPassword() == null || user.getPassword().trim().isEmpty()) {
                return "Invalid signup data. Username, email, and password are required.";
            }

            if (userRepo.findById(user.getUsername()).isPresent()) {
                return "Username already exists!";
            }
            if (userRepo.findByEmail(user.getEmail()).isPresent()) {
                return "Email already registered!";
            }

            userRepo.save(user);
            return "SignUp successful!";
        } catch (DataAccessException e) {
            return "Database error during signup: " + e.getMessage();
        } catch (Exception e) {
            return "Unexpected error during signup: " + e.getMessage();
        }
    }

    // Login
    public String login(User user) {
        try {
            if (user == null ||
                    ((user.getUsername() == null || user.getUsername().trim().isEmpty()) &&
                            (user.getEmail() == null || user.getEmail().trim().isEmpty()))) {
                return "Username or email is required for login.";
            }

            if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
                return "Password is required for login.";
            }

            User dbUser = null;

            // Try finding by username
            if (user.getUsername() != null && !user.getUsername().isEmpty()) {
                Optional<User> userByUsername = userRepo.findById(user.getUsername());
                if (userByUsername.isPresent()) {
                    dbUser = userByUsername.get();
                }
            }

            // Try finding by email
            if (dbUser == null && user.getEmail() != null && !user.getEmail().isEmpty()) {
                Optional<User> userByEmail = userRepo.findByEmail(user.getEmail());
                if (userByEmail.isPresent()) {
                    dbUser = userByEmail.get();
                }
            }

            if (dbUser == null) {
                return "User does not exist. Please signup.";
            }

            if (dbUser.getPassword() == null || !dbUser.getPassword().equals(user.getPassword())) {
                return "Invalid credentials. Please try again.";
            }

            return "Login successful! Welcome " + (dbUser.getFullName() != null ? dbUser.getFullName() : dbUser.getUsername());

        } catch (DataAccessException e) {
            return "Database error during login: " + e.getMessage();
        } catch (Exception e) {
            return "Unexpected error during login: " + e.getMessage();
        }
    }

    // Get user by username
    public User getUserByUsername(String username) {
        try {
            if (username == null || username.trim().isEmpty()) {
                return null;
            }
            return userRepo.findByUsername(username);
        } catch (DataAccessException e) {
            System.err.println("Database error while fetching user: " + e.getMessage());
            return null;
        } catch (Exception e) {
            System.err.println("Unexpected error while fetching user: " + e.getMessage());
            return null;
        }
    }

    // Forget password
    public String forgetPassword(String username) {
        try {
            if (username == null || username.trim().isEmpty()) {
                return "Username is required to get password.";
            }

            User user = userRepo.findByUsername(username);
            if (user == null) {
                return "User not found.";
            }

            return user.getPassword(); // ⚠️ Sending raw password (not secure)
        } catch (DataAccessException e) {
            return "Database error while fetching password: " + e.getMessage();
        } catch (Exception e) {
            return "Unexpected error while fetching password: " + e.getMessage();
        }
    }

}
