package com.campulse.service;

import com.campulse.DTO.ProfileDTO;
import com.campulse.DTO.TeamFindApplyDTO;
import com.campulse.DTO.TeamMemberDTO;
import com.campulse.entity.Profile.*;
import com.campulse.repo.Profile.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class ProfileService {
    @Autowired
    private ProfileRepo profileRepo;
    @Autowired
    private ProfileAchievementRepo profileAchievementRepo;
    @Autowired
    private ProfileInterestRepo profileInterestRepo;
    @Autowired
    private ProfileProjectRepo profileProjectRepo;
    @Autowired
    private ProfileSkillRepo profileSkillRepo;
    @Autowired
    TeamFindApplyRepo teamFindApplyRepo;

    // ---------- Create ----------
    public String createProfile(ProfileDTO profileDTO) {
        try {
            if (profileDTO == null || profileDTO.getUsername() == null || profileDTO.getUsername().trim().isEmpty()) {
                return "Invalid profile data. Username cannot be null or empty.";
            }

            if (profileRepo.findByUsername(profileDTO.getUsername()).isPresent()) {
                return "Profile already exists with username: " + profileDTO.getUsername();
            }

            // Save profile
            profileRepo.save(new Profile(
                    profileDTO.getUsername(),
                    safeString(profileDTO.getFullName()),
                    safeString(profileDTO.getBranch()),
                    safeString(profileDTO.getCollege()),
                    profileDTO.getYear(),
                    safeString(profileDTO.getPhone()),
                    safeString(profileDTO.getGithubLink()),
                    safeString(profileDTO.getBio()),
                    safeString(profileDTO.getLinkedinLink())
            ));

            // Save relations
            for (String i : safeList(profileDTO.getSkills()))
                profileSkillRepo.save(new ProfileSkill(profileDTO.getUsername(), i));

            for (String i : safeList(profileDTO.getAchievements()))
                profileAchievementRepo.save(new ProfileAchievement(profileDTO.getUsername(), i));

            for (String i : safeList(profileDTO.getInterests()))
                profileInterestRepo.save(new ProfileInterest(profileDTO.getUsername(), i));

            for (String i : safeList(profileDTO.getProjects()))
                profileProjectRepo.save(new ProfileProject(profileDTO.getUsername(), i));

            return "Profile created successfully!";
        } catch (DataAccessException e) {
            return "Database error while creating profile: " + e.getMessage();
        } catch (Exception e) {
            return "Unexpected error while creating profile: " + e.getMessage();
        }
    }

    // ---------- Get by Username ----------
    public ProfileDTO getProfileByUsername(String username) {
        try {
            if (username == null || username.trim().isEmpty()) {
                return null;
            }

            Optional<Profile> profileOpt = profileRepo.findByUsername(username);
            if (profileOpt.isEmpty()) {
                return null;
            }

            Profile profile = profileOpt.get();
            ProfileDTO temp = new ProfileDTO();
            temp.setUsername(profile.getUsername());
            temp.setBio(profile.getBio());
            temp.setBranch(profile.getBranch());
            temp.setCollege(profile.getCollege());
            temp.setFullName(profile.getFullName());
            temp.setLinkedinLink(profile.getLinkedinLink());
            temp.setGithubLink(profile.getGithubLink());
            temp.setPhone(profile.getPhone());
            temp.setYear(profile.getYear());

            // Achievements
            List<ProfileAchievement> achievementObj = profileAchievementRepo.findAllByUsername(username);
            List<String> achievements = new ArrayList<>();
            for (ProfileAchievement p : achievementObj)
                achievements.add(p.getAchievement());
            temp.setAchievements(achievements);

            // Interests
            List<ProfileInterest> interestObj = profileInterestRepo.findAllByUsername(username);
            List<String> interests = new ArrayList<>();
            for (ProfileInterest p : interestObj)
                interests.add(p.getInterest());
            temp.setInterests(interests);

            // Projects
            List<ProfileProject> projectObj = profileProjectRepo.findAllByUsername(username);
            List<String> projects = new ArrayList<>();
            for (ProfileProject p : projectObj)
                projects.add(p.getProject());
            temp.setProjects(projects);

            // Skills
            List<ProfileSkill> skillObj = profileSkillRepo.findAllByUsername(username);
            List<String> skills = new ArrayList<>();
            for (ProfileSkill p : skillObj)
                skills.add(p.getSkill());
            temp.setSkills(skills);

            return temp;
        } catch (DataAccessException e) {
            System.err.println("Database error while fetching profile: " + e.getMessage());
            return null;
        } catch (Exception e) {
            System.err.println("Unexpected error while fetching profile: " + e.getMessage());
            return null;
        }
    }

    // ---------- Update ----------
    public String updateProfile(ProfileDTO profileDTO) {
        try {
            Optional<Profile> profileOpt = profileRepo.findByUsername(profileDTO.getUsername());
            if (profileOpt.isEmpty()) {
                return "Profile not found with username: " + profileDTO.getUsername();
            }

            Profile profile = profileOpt.get();
            profile.setFullName(safeString(profileDTO.getFullName()));
            profile.setBranch(safeString(profileDTO.getBranch()));
            profile.setCollege(safeString(profileDTO.getCollege()));
            profile.setYear(profileDTO.getYear());
            profile.setPhone(safeString(profileDTO.getPhone()));
            profile.setGithubLink(safeString(profileDTO.getGithubLink()));
            profile.setBio(safeString(profileDTO.getBio()));
            profile.setLinkedinLink(safeString(profileDTO.getLinkedinLink()));
            profileRepo.save(profile);

            // Clear old relations
            profileAchievementRepo.deleteAllByUsername(profileDTO.getUsername());
            profileInterestRepo.deleteAllByUsername(profileDTO.getUsername());
            profileProjectRepo.deleteAllByUsername(profileDTO.getUsername());
            profileSkillRepo.deleteAllByUsername(profileDTO.getUsername());

            // Add updated relations
            for (String i : safeList(profileDTO.getAchievements()))
                profileAchievementRepo.save(new ProfileAchievement(profileDTO.getUsername(), i));

            for (String i : safeList(profileDTO.getInterests()))
                profileInterestRepo.save(new ProfileInterest(profileDTO.getUsername(), i));

            for (String i : safeList(profileDTO.getProjects()))
                profileProjectRepo.save(new ProfileProject(profileDTO.getUsername(), i));

            for (String i : safeList(profileDTO.getSkills()))
                profileSkillRepo.save(new ProfileSkill(profileDTO.getUsername(), i));

            return "Profile updated successfully!";
        } catch (DataAccessException e) {
            return "Database error while updating profile: " + e.getMessage();
        } catch (Exception e) {
            return "Unexpected error while updating profile: " + e.getMessage();
        }
    }

    // ---------- Delete ----------
    public String deleteProfile(String username) {
        try {
            Optional<Profile> profileOpt = profileRepo.findByUsername(username);
            if (profileOpt.isEmpty()) {
                return "Profile not found with username: " + username;
            }

            profileAchievementRepo.deleteAllByUsername(username);
            profileInterestRepo.deleteAllByUsername(username);
            profileProjectRepo.deleteAllByUsername(username);
            profileSkillRepo.deleteAllByUsername(username);

            profileRepo.delete(profileOpt.get());
            return "Profile deleted successfully!";
        } catch (DataAccessException e) {
            return "Database error while deleting profile: " + e.getMessage();
        } catch (Exception e) {
            return "Unexpected error while deleting profile: " + e.getMessage();
        }
    }

    // ---------- Utility Methods ----------
    private String safeString(String value) {
        return (value == null) ? "" : value.trim();
    }

    private List<String> safeList(List<String> list) {
        return (list == null) ? Collections.emptyList() : list;
    }

    public List<TeamMemberDTO> getAllTeamMembers() {
        List<TeamMemberDTO> res = new ArrayList<>();
        List<Profile> profiles = profileRepo.findAll();
        for(Profile i : profiles){
            List<ProfileSkill> skills = profileSkillRepo.findAllByUsername(i.getUsername());
            List<String> skill = new ArrayList<>();
            for(ProfileSkill j : skills)
                    skill.add(j.getSkill());
            res.add(new TeamMemberDTO(
                    i.getUsername(),
                    i.getFullName(),
                    i.getBranch(),
                    skill
            ));
        }
        return res;
    }

    public String applyTeam(TeamFindApplyDTO teamFindApplyDTO) {
        try {
            if (teamFindApplyDTO == null) {
                return "Invalid request: team application cannot be null.";
            }
            TeamFindApply temp = new TeamFindApply();
            temp.setUsername(teamFindApplyDTO.getUsername());
            temp.setBranch(teamFindApplyDTO.getBranch());
            temp.setMyUsername(teamFindApplyDTO.getMyUsername());
            temp.setFullName(teamFindApplyDTO.getFullName());
            teamFindApplyRepo.save(temp);
            return "Successfully sent apply request";
        } catch (DataAccessException e) {
            return "Database error while applying for team: " + e.getMessage();
        } catch (Exception e) {
            return "Unexpected error while applying for team: " + e.getMessage();
        }
    }

    public List<TeamFindApplyDTO> getAllApplied(String myUsername){
        List<TeamFindApplyDTO> res = new ArrayList<>();
        List<TeamFindApply> profiles = teamFindApplyRepo.findAllByMyUsername(myUsername);
        for(TeamFindApply i : profiles){
            List<ProfileSkill> skills = profileSkillRepo.findAllByUsername(i.getUsername());
            List<String> skill = new ArrayList<>();
            for(ProfileSkill j : skills)
                skill.add(j.getSkill());
            res.add(new TeamFindApplyDTO(
                    i.getMyUsername(),
                    i.getUsername(),
                    i.getFullName(),
                    i.getBranch(),
                    skill
                    //String myUserName, String username, String fullName, String branch, List<String> skills
            ));
        }
        return res;
    }

}
