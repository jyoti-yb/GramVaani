package com.campulse.service;

import com.campulse.DTO.ProjectApplyDTO;
import com.campulse.DTO.ProjectUploadDTO;
import com.campulse.entity.ChatGroup;
import com.campulse.entity.Project.*;
import com.campulse.entity.Project.Validation.Ideas;
import com.campulse.entity.Project.Validation.ValidateComments;
import com.campulse.repo.ChatGroupRepo;
import com.campulse.repo.Project.*;
import com.campulse.repo.Project.Validation.IdeasRepo;
import com.campulse.repo.Project.Validation.ValidateCommentsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProjectService {

    @Autowired
    ProjectUploadRepo projectUploadRepo;
    @Autowired
    ProjectTechnologyRepo projectTechnologyRepo;
    @Autowired
    ProjectApplyRepo projectApplyRepo;
    @Autowired
    private ChatGroupRepo chatGroupRepo;


    public String uploadProject(ProjectUploadDTO projectUploadDTO) {
        if (projectUploadDTO == null || projectUploadDTO.getTitle() == null) {
            return "Invalid project data.";
        }
        try {
            ProjectUpload projectUpload = new ProjectUpload(
                    projectUploadDTO.getTitle(),
                    projectUploadDTO.getTeamLead(),
                    projectUploadDTO.getFullName(),
                    projectUploadDTO.getDescription(),
                    projectUploadDTO.getDate(),
                    projectUploadDTO.getMaxTeamMembers(),
                    projectUploadDTO.getCategory()
            );
            projectUploadRepo.save(projectUpload);

            for (String i : projectUploadDTO.getTechnologies()) {
                ProjectTechnology pt = new ProjectTechnology();
                pt.setTechnology(i);
                pt.setTitle(projectUploadDTO.getTitle());
                projectTechnologyRepo.save(pt);
            }

            // ✅ Create ChatGroup row for team lead
            ChatGroup group = new ChatGroup(projectUploadDTO.getTitle(), projectUploadDTO.getTeamLead());
            chatGroupRepo.save(group);

            return "Successfully added project";
        } catch (Exception e) {
            return "Failed to upload project: " + e.getMessage();
        }
    }



    public List<ProjectUploadDTO> getAllProjects() {
        List<ProjectUploadDTO> res = new ArrayList<>();
        try {
            List<ProjectUpload> pu = projectUploadRepo.findAll();
            for (ProjectUpload i : pu) {
                List<String> li = new ArrayList<>();
                List<ProjectTechnology> pt = projectTechnologyRepo.findAllByTitle(i.getTitle());
                for (ProjectTechnology j : pt) li.add(j.getTechnology());

                res.add(new ProjectUploadDTO(
                        i.getId(),
                        i.getTitle(),
                        i.getTeamLead(),
                        i.getFullName(),
                        i.getDescription(),
                        i.getDate(),
                        li,
                        i.getMaxTeamMembers(),
                        i.getCurrentTeamMembers(),
                        i.getCategory() // ✅ NEW
                ));
            }
        } catch (Exception e) {
            return res;
        }
        return res;
    }



    public String deleteProject(long id) {
        try {
            Optional<ProjectUpload> project = projectUploadRepo.findById(id);
            if (project.isEmpty()) {
                return "Project not found with id " + id;
            }

            String title = project.get().getTitle();

            // ✅ Delete chat group members associated with the project
            List<ChatGroup> groupMembers = chatGroupRepo.findByGroupName(title);
            if (!groupMembers.isEmpty()) {
                chatGroupRepo.deleteAll(groupMembers);
            }

            // ✅ Delete project applications related to this project
            List<ProjectApply> applications = projectApplyRepo.findAllByProjectName(title);
            if (!applications.isEmpty()) {
                projectApplyRepo.deleteAll(applications);
            }

            // ✅ Delete project technologies
            projectTechnologyRepo.deleteAllByTitle(title);

            // ✅ Delete project itself
            projectUploadRepo.deleteById(id);

            return "Deleted project, related applications, and chat groups successfully";
        } catch (Exception e) {
            return "Failed to delete project: " + e.getMessage();
        }
    }



    public String applyProject(ProjectApplyDTO projectApplyDTO) {
        try {
            if (projectApplyDTO == null) return "Invalid project apply request.";
            projectApplyRepo.save(new ProjectApply(
                    projectApplyDTO.getTitle(),
                    projectApplyDTO.getMyUsername(),
                    projectApplyDTO.getUsername(),
                    projectApplyDTO.getFullName(),
                    projectApplyDTO.getProjectName(),
                    projectApplyDTO.getDescription(),
                    false,
                    projectApplyDTO.getCategory() // ✅ NEW
            ));
            return "Project applied successfully";
        } catch (Exception e) {
            return "Failed to apply for project: " + e.getMessage();
        }
    }


    public List<ProjectApply> getAllProjectApply(String applicant) {
        try {
            return projectApplyRepo.findAllByApplicant(applicant);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public String acceptApplicant(ProjectApplyDTO projectApplyDTO) {
        try {
            Optional<ProjectApply> dummyOpt = projectApplyRepo.findById(projectApplyDTO.getId());
            if (dummyOpt.isEmpty()) return "Application not found.";

            ProjectApply dummy = dummyOpt.get();

            if (dummy.getAccept()) {
                return "Applicant already accepted.";
            }

            Optional<ProjectUpload> projectOpt = projectUploadRepo.findByTitle(dummy.getProjectName());
            if (projectOpt.isEmpty()) return "Project not found.";

            ProjectUpload project = projectOpt.get();

            if (project.getCurrentTeamMembers() >= project.getMaxTeamMembers()) {
                return "Team is already full. Cannot accept more members.";
            }

            dummy.setAccept(true);
            projectApplyRepo.save(dummy);

            project.setCurrentTeamMembers(project.getCurrentTeamMembers() + 1);
            projectUploadRepo.save(project);

            // ✅ Add applicant into ChatGroup
            ChatGroup newMember = new ChatGroup(project.getTitle(), dummy.getApplicant());
            chatGroupRepo.save(newMember);

            return "Successfully accepted";
        } catch (Exception e) {
            return "Failed to accept applicant: " + e.getMessage();
        }
    }



    public List<ProjectApply> getAllProjectApplied(String teamLead) {
        try {
            return projectApplyRepo.findAllByTeamLead(teamLead);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    @Autowired
    private IdeasRepo ideasRepo;

    @Autowired
    private ValidateCommentsRepo commentsRepo;

    // ---------------- IDEA METHODS ----------------
    public String addIdea(Ideas idea) {
        if (idea == null || idea.getTitle() == null) {
            return "Invalid idea data.";
        }
        try {
            if (idea.getDate() == null) {
                idea.setDate(LocalDate.now());
            }
            ideasRepo.save(idea);
            return "Idea added successfully.";
        } catch (Exception e) {
            return "Failed to add idea: " + e.getMessage();
        }
    }

    public List<Ideas> getAllIdeas() {
        try {
            return ideasRepo.findAll();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public Ideas getIdeaByTitle(String title) {
        return ideasRepo.findById(title).orElse(null);
    }

    public String deleteIdea(String title) {
        try {
            if (!ideasRepo.existsById(title)) {
                return "Idea not found with title: " + title;
            }
            ideasRepo.deleteById(title);
            return "Idea deleted successfully.";
        } catch (Exception e) {
            return "Failed to delete idea: " + e.getMessage();
        }
    }

    // ---------------- COMMENTS METHODS ----------------
    public String addComment(ValidateComments comment) {
        if (comment == null || comment.getTitle() == null) {
            return "Invalid comment data.";
        }
        try {
            commentsRepo.save(comment);
            return "Comment added successfully.";
        } catch (Exception e) {
            return "Failed to add comment: " + e.getMessage();
        }
    }

    public List<ValidateComments> getCommentsByTitle(String title) {
        try {
            return commentsRepo.findAllByTitle(title);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public String deleteComment(Long id) {
        try {
            Optional<ValidateComments> comment = commentsRepo.findById(id);
            if (comment.isEmpty()) {
                return "Comment not found with id " + id;
            }
            commentsRepo.deleteById(id);
            return "Comment deleted successfully.";
        } catch (Exception e) {
            return "Failed to delete comment: " + e.getMessage();
        }
    }
    @Autowired
    private MiscellaneousProjectApplyRepo miscellaneousProjectApplyRepo;

    @Autowired
    private MiscellaneousProjectRepo miscellaneousProjectRepo;

    // Create new Miscellaneous project
    public MiscellaneousProject createMiscellaneousProject(MiscellaneousProject project) {
        MiscellaneousProject saved = miscellaneousProjectRepo.save(project);

        // ✅ Create ChatGroup row for team lead
        ChatGroup group = new ChatGroup(project.getTeamName(), project.getTeamLead());
        chatGroupRepo.save(group);

        return saved;
    }

    // Get all Miscellaneous projects
    public List<MiscellaneousProject> getAllMiscellaneousProjects() {
        return miscellaneousProjectRepo.findAll();
    }

    // Apply to Miscellaneous project
    public MiscellaneousProjectApply applyToMiscellaneousProject(MiscellaneousProjectApply application) {
        return miscellaneousProjectApplyRepo.save(application); // ✅ fixed
    }

    // Accept candidate for Miscellaneous project
    public MiscellaneousProjectApply acceptMiscellaneousCandidate(Long applicationId) {
        MiscellaneousProjectApply application = miscellaneousProjectApplyRepo.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found"));

        MiscellaneousProject project = miscellaneousProjectRepo.findByTeamName(application.getTeamName());
        if (project == null) {
            throw new RuntimeException("Project not found for teamName: " + application.getTeamName());
        }

        if (project.getCurrentSize() < project.getMaxSize()) {
            application.setAccepted(true);
            project.setCurrentSize(project.getCurrentSize() + 1);
            miscellaneousProjectRepo.save(project);

            MiscellaneousProjectApply saved = miscellaneousProjectApplyRepo.save(application);

            // ✅ Add applicant into ChatGroup
            ChatGroup newMember = new ChatGroup(application.getTeamName(), application.getApplicant());
            chatGroupRepo.save(newMember);

            return saved;
        } else {
            throw new RuntimeException("Team is already full");
        }
    }

    public String deleteMiscellaneousProject(String teamName) {
        try {
            Optional<MiscellaneousProject> projectOpt = miscellaneousProjectRepo.findById(teamName);
            if (projectOpt.isEmpty()) {
                return "Miscellaneous project not found with teamName: " + teamName;
            }

            // ✅ Delete chat group members associated with this team
            List<ChatGroup> groupMembers = chatGroupRepo.findByGroupName(teamName);
            if (!groupMembers.isEmpty()) {
                chatGroupRepo.deleteAll(groupMembers);
            }

            // ✅ Delete all applications related to this team
            List<MiscellaneousProjectApply> applications = miscellaneousProjectApplyRepo.findByTeamName(teamName);
            if (!applications.isEmpty()) {
                miscellaneousProjectApplyRepo.deleteAll(applications);
            }

            // ✅ Delete the project itself
            miscellaneousProjectRepo.deleteById(teamName);

            return "Deleted miscellaneous project, related applications, and chat groups successfully";
        } catch (Exception e) {
            return "Failed to delete miscellaneous project: " + e.getMessage();
        }
    }




    // Get all applications for a Miscellaneous team
    public List<MiscellaneousProjectApply> getApplicationsForMiscellaneousTeam(String teamName) {
        return miscellaneousProjectApplyRepo.findByTeamName(teamName);
    }

    public List<ChatGroup> getGroupMembers(String groupName) {
        return chatGroupRepo.findByGroupName(groupName);
    }


}
