package com.campulse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampulseNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampulseNewApplication.class, args);
	}

}
