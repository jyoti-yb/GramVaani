package com.campulse.DTO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TeamFindApplyDTO {
    private long id;

    private String myUsername;
    private String username;
    private String fullName;
    private String branch;

    private List<String> skills = new ArrayList<>();

    // ---------- Constructors ----------
    public TeamFindApplyDTO() {
    }
    public TeamFindApplyDTO(String myUsername, String username, String fullName, String branch, List<String> skills) {
        this.myUsername = myUsername;
        this.username = username;
        this.fullName = fullName;
        this.branch = branch;
        this.skills = skills;
    }


    // ---------- Getters & Setters ----------
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    public String getMyUsername() {
        return myUsername;
    }
    public void setMyUsername(String myUsername) {
        this.myUsername = (myUsername != null) ? myUsername : "";
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = (username != null) ? username : "";
    }

    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = (fullName != null) ? fullName : "";
    }

    public String getBranch() {
        return branch;
    }
    public void setBranch(String branch) {
        this.branch = (branch != null) ? branch : "";
    }

    public List<String> getSkills() {
        return Collections.unmodifiableList(skills);
    }
    public void setSkills(List<String> skills) {
        this.skills = (skills != null) ? new ArrayList<>(skills) : new ArrayList<>();
    }

    // ---------- toString ----------
    @Override
    public String toString() {
        return "TeamFindApply [id=" + id + ", myUserName=" + myUsername +
                ", username=" + username + ", fullName=" + fullName +
                ", branch=" + branch + ", skills=" + skills + "]";
    }
}
