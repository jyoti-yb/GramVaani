package com.campulse.DTO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProjectApplyDTO {
    private long id;
    private String title;

    private String myUsername;
    private String username;
    private String fullName;
    private String projectName;
    private String description;
    private List<String> technologies = new ArrayList<>();
    private boolean accept;
    private String category; // ✅ NEW FIELD

    public ProjectApplyDTO(){}

    public ProjectApplyDTO(long id, String title, String myUsername, String username,
                           String fullName, String projectName, String description,
                           List<String> technologies, boolean accept, String category) {
        this.id = id;
        this.title = (title != null) ? title : "";
        this.myUsername = (myUsername != null) ? myUsername : "";
        this.username = (username != null) ? username : "";
        this.fullName = (fullName != null) ? fullName : "";
        this.projectName = (projectName != null) ? projectName : "";
        this.description = (description != null) ? description : "";
        this.technologies = (technologies != null) ? new ArrayList<>(technologies) : new ArrayList<>();
        this.accept = accept;
        this.category = (category != null) ? category : "";
    }

    // ---------- Getters & Setters ----------
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public boolean getAccept(){ return accept; }
    public void setAccept(boolean accept){ this.accept = accept; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = (title != null) ? title : ""; }

    public String getMyUsername() { return myUsername; }
    public void setMyUsername(String myUsername) { this.myUsername = (myUsername != null) ? myUsername : ""; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = (username != null) ? username : ""; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = (fullName != null) ? fullName : ""; }

    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = (projectName != null) ? projectName : ""; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = (description != null) ? description : ""; }

    public List<String> getTechnologies() { return Collections.unmodifiableList(technologies); }
    public void setTechnologies(List<String> technologies) { this.technologies = (technologies != null) ? new ArrayList<>(technologies) : new ArrayList<>(); }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = (category != null) ? category : ""; }

    @Override
    public String toString() {
        return "ProjectApply [id=" + id + ", title=" + title + ", myUserName=" + myUsername +
                ", username=" + username + ", fullName=" + fullName +
                ", projectName=" + projectName + ", description=" + description +
                ", technologies=" + technologies + ", accept=" + accept +
                ", category=" + category + "]";
    }
}
