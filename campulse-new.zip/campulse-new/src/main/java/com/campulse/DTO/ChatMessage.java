package com.campulse.DTO;

public class ChatMessage {
    private String groupName;
    private String sender;
    private String content;
    private String messageType; // CHAT, JOIN, LEAVE
    private String timestamp;   // formatted for frontend

    public ChatMessage() {}

    public ChatMessage(String groupName, String sender, String content, String messageType, String timestamp) {
        this.groupName = groupName;
        this.sender = sender;
        this.content = content;
        this.messageType = messageType;
        this.timestamp = timestamp;
    }

    // Getters & Setters
    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
