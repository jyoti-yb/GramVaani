package com.campulse.DTO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class TeamMemberDTO {
    private String username;
    private String fullName;
    private String branch;
    private List<String> skills = new ArrayList<>();;

    public TeamMemberDTO(){

    }


    public TeamMemberDTO(String username, String fullName, String branch, List<String> skills) {
        this.username = (username != null) ? username : "Unknown";
        this.fullName = (fullName != null) ? fullName : "Unnamed User";
        this.branch = (branch != null) ? branch : "Not Specified";
        // Defensive copy & null check to prevent NullPointerException
        this.skills = (skills != null) ? List.copyOf(skills) : Collections.emptyList();
    }

    public String getUsername() {
        return username;
    }

    public String getFullName() {
        return fullName;
    }

    public String getBranch() {
        return branch;
    }

    public List<String> getSkills() {
        return skills;
    }

    @Override
    public String toString() {
        return "TeamMemberDTO{" +
                "username='" + username + '\'' +
                ", fullName='" + fullName + '\'' +
                ", branch='" + branch + '\'' +
                ", skills=" + skills +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TeamMemberDTO)) return false;
        TeamMemberDTO that = (TeamMemberDTO) o;
        return Objects.equals(username, that.username) &&
                Objects.equals(fullName, that.fullName) &&
                Objects.equals(branch, that.branch) &&
                Objects.equals(skills, that.skills);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username, fullName, branch, skills);
    }
}
