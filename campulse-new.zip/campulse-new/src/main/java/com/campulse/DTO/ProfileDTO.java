package com.campulse.DTO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProfileDTO {
    private String username;

    private String fullName;
    private String branch;
    private String college;
    private int year;
    private List<String> projects = new ArrayList<>();
    private List<String> skills = new ArrayList<>();
    private List<String> interests = new ArrayList<>();
    private List<String> achievements = new ArrayList<>();
    private String bio;
    private String phone;
    private String githubLink;
    private String linkedinLink;
    // ---------- Constructors ----------
    public ProfileDTO() {
    }

    public ProfileDTO(String fullName, String username, String branch, int year, String college, List<String> projects, List<String> skills, List<String> interests, List<String> achievements, String bio, String phone, String githubLink, String linkedinLink) {
        this.fullName = fullName;
        this.username = username;
        this.branch = branch;
        this.year = year;
        this.college = college;
        this.projects = projects;
        this.skills = skills;
        this.interests = interests;
        this.achievements = achievements;
        this.bio = bio;
        this.phone = phone;
        this.githubLink = githubLink;
        this.linkedinLink = linkedinLink;
    }

    // ---------- Getters & Setters ----------
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = (username != null) ? username : "";
    }

    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = (fullName != null) ? fullName : "";
    }

    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        this.year = year;
    }

    public String getBranch() {
        return branch;
    }
    public void setBranch(String branch) {
        this.branch = (branch != null) ? branch : "";
    }

    public String getCollege() {
        return college;
    }
    public void setCollege(String college) {
        this.college = (college != null) ? college : "";
    }

    public List<String> getProjects() {
        return Collections.unmodifiableList(projects);
    }
    public void setProjects(List<String> projects) {
        this.projects = (projects != null) ? new ArrayList<>(projects) : new ArrayList<>();
    }

    public List<String> getSkills() {
        return Collections.unmodifiableList(skills);
    }
    public void setSkills(List<String> skills) {
        this.skills = (skills != null) ? new ArrayList<>(skills) : new ArrayList<>();
    }

    public List<String> getInterests() {
        return Collections.unmodifiableList(interests);
    }
    public void setInterests(List<String> interests) {
        this.interests = (interests != null) ? new ArrayList<>(interests) : new ArrayList<>();
    }

    public List<String> getAchievements() {
        return Collections.unmodifiableList(achievements);
    }
    public void setAchievements(List<String> achievements) {
        this.achievements = (achievements != null) ? new ArrayList<>(achievements) : new ArrayList<>();
    }

    public String getBio() {
        return bio;
    }
    public void setBio(String bio) {
        this.bio = (bio != null) ? bio : "";
    }

    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = (phone != null) ? phone : "";
    }

    public String getGithubLink() {
        return githubLink;
    }
    public void setGithubLink(String githubLink) {
        this.githubLink = (githubLink != null) ? githubLink : "";
    }

    public String getLinkedinLink() {
        return linkedinLink;
    }
    public void setLinkedinLink(String linkedinLink) {
        this.linkedinLink = (linkedinLink != null) ? linkedinLink : "";
    }

    // ---------- toString ----------
    @Override
    public String toString() {
        return "Profile [username=" + username + ", fullName=" + fullName + ", branch=" + branch +
                ", college=" + college + ", year=" + year + ", projects=" + projects +
                ", skills=" + skills + ", interests=" + interests + ", achievements=" + achievements +
                ", bio=" + bio + ", phone=" + phone + ", githubLink=" + githubLink +
                ", linkedinLink=" + linkedinLink + "]";
    }
}
