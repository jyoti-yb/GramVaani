import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Instagram, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const Support = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <Navigation />
      
      <div className="pt-24 pb-8 px-4 max-w-4xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold mb-2 flex items-center justify-center gap-3">
            <HelpCircle className="text-primary" size={40} />
            Support
          </h1>
          <p className="text-muted-foreground text-lg">
            We're here to help! Reach out to us anytime.
          </p>
        </div>

        <div className="space-y-6">
          <Card className="shadow-lg border-2 border-muted hover:border-primary/30 transition-colors">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="text-primary" size={24} />
                Email Support
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Have questions or need assistance? Send us an email and we'll get back to you as soon as possible.
              </p>
              <div className="flex items-center gap-2">
                <Button asChild className="bg-gradient-primary">
                  <a href="mailto:infocampulse2025@gmail.com">
                    <Mail size={18} className="mr-2" />
                    infocampulse2025@gmail.com
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-2 border-muted hover:border-primary/30 transition-colors">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Instagram className="text-primary" size={24} />
                Follow Us on Instagram
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Stay updated with the latest news, features, and community highlights by following us on Instagram.
              </p>
              <div className="flex items-center gap-2">
                <Button asChild variant="outline" className="border-primary/30">
                  <a
                    href="https://www.instagram.com/campulse2025/"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Instagram size={18} className="mr-2" />
                    @campulse2025
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-2 border-primary/20 bg-gradient-to-br from-card to-primary/5">
            <CardHeader>
              <CardTitle>About Campulse</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-muted-foreground leading-relaxed">
                Campulse is a collaborative platform designed to connect students, facilitate team formation, 
                and streamline project management in academic environments. Our mission is to empower students 
                to collaborate effectively, share ideas, and build amazing projects together.
              </p>
              <div className="pt-2">
                <h4 className="font-semibold mb-2">Key Features:</h4>
                <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                  <li>Team formation and project collaboration</li>
                  <li>Real-time group chat for project teams</li>
                  <li>Project idea sharing and validation</li>
                  <li>Application management for team recruitment</li>
                  <li>Campus-wide activity feed</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Support;
