import { useState, useEffect } from 'react';
import Navigation from "@/components/Navigation";
import FeedCard from "@/components/FeedCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Search, Plus, Users, Loader2 } from "lucide-react";
import { getAllFeeds, createFeed, getProfile, deleteFeed, updateFeed, type Feed, type Profile } from '@/lib/api';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

const Home = () => {
  const [feeds, setFeeds] = useState<Feed[]>([]);
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingFeed, setEditingFeed] = useState<Feed | null>(null);
  const [newPost, setNewPost] = useState({
    title: '',
    description: '',
    department: ''
  });
  const [editPost, setEditPost] = useState({
    title: '',
    description: '',
    department: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { username } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    fetchFeeds();
  }, []);

  const fetchFeeds = async () => {
    try {
      setIsLoading(true);
      const feedsData = await getAllFeeds();
      setFeeds(feedsData);
      
      // Fetch profiles for feed authors
      const uniqueUsernames = [...new Set(feedsData.map(feed => feed.username))];
      const profilePromises = uniqueUsernames.map(async (username) => {
        try {
          const profile = await getProfile(username);
          return { username, profile };
        } catch {
          return { username, profile: null };
        }
      });
      
      const profileResults = await Promise.all(profilePromises);
      const profileMap: Record<string, Profile> = {};
      profileResults.forEach(({ username, profile }) => {
        if (profile) {
          profileMap[username] = profile;
        }
      });
      setProfiles(profileMap);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load feeds. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreatePost = async () => {
    if (!newPost.title.trim() && !newPost.description.trim()) {
      toast({
        title: "Missing Content",
        description: "Please provide at least a title or description.",
        variant: "destructive",
      });
      return;
    }

    if (!username) {
      toast({
        title: "Authentication Required",
        description: "Please log in to create a post.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await createFeed({
        title: newPost.title,
        description: newPost.description,
        username: username,
        department: newPost.department || 'General'
      });

      toast({
        title: "Post Created",
        description: "Your post has been published successfully.",
      });

      setNewPost({ title: '', description: '', department: '' });
      setIsDialogOpen(false);
      fetchFeeds(); // Refresh feeds
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditFeed = (feed: Feed) => {
    setEditingFeed(feed);
    setEditPost({
      title: feed.title,
      description: feed.description,
      department: feed.department
    });
    setIsEditDialogOpen(true);
  };

  const handleUpdateFeed = async () => {
    if (!editingFeed) return;

    setIsSubmitting(true);
    try {
      await updateFeed({
        ...editingFeed,
        title: editPost.title,
        description: editPost.description,
        department: editPost.department
      });

      toast({
        title: "Post Updated",
        description: "Your post has been updated successfully.",
      });

      setIsEditDialogOpen(false);
      setEditingFeed(null);
      fetchFeeds();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update post. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteFeed = async (feedId: number) => {
    if (!confirm("Are you sure you want to delete this post?")) return;

    try {
      await deleteFeed(feedId);
      toast({
        title: "Post Deleted",
        description: "Your post has been deleted successfully.",
      });
      fetchFeeds();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete post. Please try again.",
        variant: "destructive",
      });
    }
  };

  const filteredFeeds = feeds.filter(feed => 
    feed.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    feed.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    feed.username.toLowerCase().includes(searchTerm.toLowerCase())
  );


  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Main Content */}
      <div className="pt-24 pb-8 px-4 max-w-6xl mx-auto">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="bg-gradient-primary rounded-2xl p-6 text-white mb-6">
            <h1 className="text-2xl font-bold mb-2">Welcome back, {profiles[username || '']?.fullName?.split(' ')[0] || username}! 👋</h1>
            <p className="text-white/90">Ready to collaborate on something amazing today?</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Feed */}
          <div className="lg:col-span-3">
            {/* Search and Create */}
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={18} />
                <Input 
                  placeholder="Search feeds, projects, or announcements..." 
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="gap-2 bg-gradient-primary text-white hover:opacity-90">
                    <Plus size={18} />
                    Create Post
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Create New Post</DialogTitle>
                    <DialogDescription>
                      Share your thoughts, projects, or announcements with the community.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="title">Title</Label>
                      <Input
                        id="title"
                        placeholder="What's on your mind?"
                        value={newPost.title}
                        onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        placeholder="Tell us more about it..."
                        className="min-h-[100px]"
                        value={newPost.description}
                        onChange={(e) => setNewPost({ ...newPost, description: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="department">Department (Optional)</Label>
                      <Input
                        id="department"
                        placeholder="e.g., Computer Science, Engineering"
                        value={newPost.department}
                        onChange={(e) => setNewPost({ ...newPost, department: e.target.value })}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleCreatePost} 
                      disabled={isSubmitting}
                      className="bg-gradient-primary text-white hover:opacity-90"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Publishing...
                        </>
                      ) : (
                        'Publish Post'
                      )}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              {/* Edit Dialog */}
              <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Edit Post</DialogTitle>
                    <DialogDescription>
                      Update your post details.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-title">Title</Label>
                      <Input
                        id="edit-title"
                        placeholder="What's on your mind?"
                        value={editPost.title}
                        onChange={(e) => setEditPost({ ...editPost, title: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-description">Description</Label>
                      <Textarea
                        id="edit-description"
                        placeholder="Tell us more about it..."
                        className="min-h-[100px]"
                        value={editPost.description}
                        onChange={(e) => setEditPost({ ...editPost, description: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-department">Department (Optional)</Label>
                      <Input
                        id="edit-department"
                        placeholder="e.g., Computer Science, Engineering"
                        value={editPost.department}
                        onChange={(e) => setEditPost({ ...editPost, department: e.target.value })}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleUpdateFeed} 
                      disabled={isSubmitting}
                      className="bg-gradient-primary text-white hover:opacity-90"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Updating...
                        </>
                      ) : (
                        'Update Post'
                      )}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>

            {/* Feed Items */}
            <div className="space-y-6">
              {isLoading ? (
                <div className="text-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-primary" />
                  <p className="text-muted-foreground">Loading feeds...</p>
                </div>
              ) : filteredFeeds.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">📢</div>
                  <h3 className="text-lg font-semibold mb-2">No posts yet</h3>
                  <p className="text-muted-foreground mb-4">
                    {searchTerm ? 'No posts match your search.' : 'Be the first to share something with the community!'}
                  </p>
                  {!searchTerm && (
                    <Button 
                      onClick={() => setIsDialogOpen(true)}
                      className="bg-gradient-primary text-white hover:opacity-90"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Create First Post
                    </Button>
                  )}
                </div>
              ) : (
                filteredFeeds.map((feed) => {
                  const profile = profiles[feed.username];
                  return (
                    <FeedCard
                      key={feed.id}
                      feedId={feed.id!}
                      title={feed.title}
                      description={feed.description}
                      username={feed.username}
                      department={feed.department}
                      userFullName={profile?.fullName}
                      userBranch={profile?.branch}
                      createdAt={(feed as any).createdAt}
                      onDelete={() => handleDeleteFeed(feed.id!)}
                      onEdit={() => handleEditFeed(feed)}
                    />
                  );
                })
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Active Team Requests */}
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users size={18} className="text-primary" />
                  Active Requests
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm text-muted-foreground">
                  You have <span className="font-medium text-foreground">3 pending</span> team requests
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  Manage Requests
                </Button>
              </CardContent>
            </Card>

          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;