import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { toast } from "@/hooks/use-toast";
import { Users, Plus } from "lucide-react";
import { 
  createMiscProject, 
  getAllMiscProjects, 
  applyToMiscProject,
  getMiscProjectApplications,
  acceptMiscProjectApplicant,
  type MiscProject,
  type MiscProjectApplication
} from "@/lib/api";

const MiscProjects = () => {
  const { username } = useAuth();
  const [projects, setProjects] = useState<MiscProject[]>([]);
  const [applications, setApplications] = useState<MiscProjectApplication[]>([]);
  const [selectedProject, setSelectedProject] = useState<MiscProject | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"all" | "requests">("all");

  const form = useForm({
    defaultValues: { teamName: "", maxSize: 5 }
  });

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      setIsLoading(true);
      const data = await getAllMiscProjects();
      setProjects(data);
    } catch (error) {
      toast({ title: "Error", description: "Failed to load projects", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const loadApplications = async (teamName: string) => {
    try {
      const data = await getMiscProjectApplications(teamName);
      setApplications(data);
    } catch (error) {
      console.error(error);
    }
  };

  const onCreateProject = async (data: any) => {
    try {
      await createMiscProject({
        teamName: data.teamName,
        teamLead: username!,
        maxSize: data.maxSize,
        currentSize: 0
      });
      toast({ title: "Success", description: "Team created!" });
      setIsCreateDialogOpen(false);
      form.reset();
      loadProjects();
    } catch (error) {
      toast({ title: "Error", description: "Failed to create team", variant: "destructive" });
    }
  };

  const handleApply = async (project: MiscProject) => {
    if (!username) return;
    try {
      await applyToMiscProject({
        teamName: project.teamName,
        teamLead: project.teamLead,
        applicant: username,
        accepted: false
      });
      toast({ title: "Success", description: "Applied successfully!" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to apply", variant: "destructive" });
    }
  };

  const handleAccept = async (applicationId: number) => {
    try {
      await acceptMiscProjectApplicant(applicationId);
      toast({ title: "Success", description: "Applicant accepted!" });
      if (selectedProject) loadApplications(selectedProject.teamName);
    } catch (error) {
      toast({ title: "Error", description: "Failed to accept", variant: "destructive" });
    }
  };

  const handleViewApplications = async (project: MiscProject) => {
    setSelectedProject(project);
    await loadApplications(project.teamName);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-24 pb-8 px-4 max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded w-48 mb-4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1,2,3,4,5,6].map(i => <div key={i} className="h-48 bg-muted rounded-lg"></div>)}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-24 pb-8 px-4 max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-1 flex items-center gap-2">
              <Users className="text-primary" size={32} />
              Team Hub
            </h1>
            <p className="text-muted-foreground">Create teams or join existing ones</p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <Button onClick={() => setIsCreateDialogOpen(true)} className="gap-2 bg-gradient-primary">
              <Plus size={18}/> Create Team
            </Button>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Team</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onCreateProject)} className="space-y-4">
                  <FormField control={form.control} name="teamName" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Name</FormLabel>
                      <FormControl><Input {...field} placeholder="Awesome Team" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}/>
                  <FormField control={form.control} name="maxSize" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Maximum Team Size</FormLabel>
                      <FormControl><Input {...field} type="number" min="1" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}/>
                  <div className="flex gap-2">
                    <Button type="submit" className="flex-1 bg-gradient-primary">Create Team</Button>
                    <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>Cancel</Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.length === 0 ? (
            <Card className="text-center p-8 col-span-full">
              <Users size={48} className="mx-auto text-muted-foreground mb-4"/>
              <p className="text-muted-foreground">No teams yet. Create one!</p>
            </Card>
          ) : projects.map(project => (
            <Card key={project.id} className="shadow-lg hover:shadow-xl transition-all">
              <CardHeader>
                <CardTitle className="text-lg flex items-center justify-between">
                  <span>{project.teamName}</span>
                  <Users size={20} className="text-primary" />
                </CardTitle>
                <p className="text-sm text-muted-foreground">Lead: {project.teamLead}</p>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <Badge variant="secondary">
                    {project.currentSize}/{project.maxSize} Members
                  </Badge>
                </div>
                <div className="flex gap-2">
                  {project.teamLead === username ? (
                    <Button size="sm" variant="outline" className="flex-1" onClick={() => handleViewApplications(project)}>
                      View Applications
                    </Button>
                  ) : (
                    <Button size="sm" className="flex-1 bg-gradient-primary" onClick={() => handleApply(project)}>
                      Apply to Join
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Applications Dialog */}
        <Dialog open={!!selectedProject} onOpenChange={open => !open && setSelectedProject(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            {selectedProject && (
              <>
                <DialogHeader>
                  <DialogTitle>Applications for {selectedProject.teamName}</DialogTitle>
                </DialogHeader>
                <div className="space-y-3">
                  {applications.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No applications yet</p>
                  ) : applications.map(app => (
                    <Card key={app.id}>
                      <CardContent className="flex justify-between items-center p-4">
                        <div>
                          <p className="font-semibold">{app.applicant}</p>
                          <Badge variant={app.accepted ? "secondary" : "outline"}>
                            {app.accepted ? "Accepted" : "Pending"}
                          </Badge>
                        </div>
                        {!app.accepted && (
                          <Button size="sm" onClick={() => handleAccept(app.id!)} className="bg-green-600 hover:bg-green-700">
                            Accept
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default MiscProjects;
