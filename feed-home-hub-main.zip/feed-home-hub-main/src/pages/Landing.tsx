import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Users, Rocket, Share2 } from 'lucide-react';

const Landing = () => {
  return (
    <div className="min-h-screen bg-gradient-primary flex flex-col">
      {/* Header */}
      <header className="flex justify-center pt-12 pb-8">
        <div className="flex items-center space-x-3 bg-white/20 backdrop-blur-sm rounded-2xl px-6 py-3">
          <Share2 className="h-8 w-8 text-white" />
          <span className="text-3xl font-bold text-white">Campulse</span>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 text-center">
        <div className="max-w-6xl mx-auto">
          {/* Main Heading */}
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-8 leading-tight">
            Connect. Collaborate. Create.
          </h1>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Button 
              asChild
              size="lg"
              className="bg-white text-primary hover:bg-white/90 font-semibold px-8 py-3 text-lg"
            >
              <Link to="/signup">
                Get Started Free →
              </Link>
            </Button>
            
            <Button 
              asChild
              variant="outline"
              size="lg"
              className="border-white/30 text-white bg-white/10 hover:bg-white/20 backdrop-blur-sm font-semibold px-8 py-3 text-lg"
            >
              <Link to="/login">
                Sign in
              </Link>
            </Button>
          </div>

          {/* Feature Cards */}
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-white mb-2">Find Your Team</h3>
              <p className="text-white/80 text-lg">
                Connect with talented students who share your passion
              </p>
            </div>

            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Rocket className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-white mb-2">Launch Projects</h3>
              <p className="text-white/80 text-lg">
                Turn your innovative ideas into real-world solutions
              </p>
            </div>

            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Share2 className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-white mb-2">Showcase Skills</h3>
              <p className="text-white/80 text-lg">
                Build your portfolio and stand out to future employers
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="text-center py-8 text-white/60">
        <p>Join the ultimate student collaboration platform where ideas come to life and teams are born.</p>
      </footer>
    </div>
  );
};

export default Landing;