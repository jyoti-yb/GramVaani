import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageSquare } from "lucide-react";

const Feedback = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <Navigation />
      
      <div className="pt-24 pb-8 px-4 max-w-4xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold mb-2 flex items-center justify-center gap-3">
            <MessageSquare className="text-primary" size={40} />
            Feedback
          </h1>
          <p className="text-muted-foreground text-lg">
            Your feedback helps us improve Campulse. Share your thoughts with us!
          </p>
        </div>

        <Card className="shadow-xl border-2 border-primary/20">
          <CardHeader>
            <CardTitle>Submit Your Feedback</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="aspect-video w-full">
              <iframe
                src="https://docs.google.com/forms/d/e/1FAIpQLSeGwFaquwg6AkMzjAIADz0SL0pN4LD3y2QT5NU68uDDN3jZoA/viewform?embedded=true"
                width="100%"
                height="100%"
                frameBorder="0"
                marginHeight={0}
                marginWidth={0}
                className="rounded-lg"
              >
                Loading…
              </iframe>
            </div>
            <p className="text-sm text-muted-foreground mt-4 text-center">
              Can't see the form? <a 
                href="https://forms.gle/Bp25yGX4v3BD3UKKA" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                Open in new tab
              </a>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Feedback;
