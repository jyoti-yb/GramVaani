import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { toast } from "@/hooks/use-toast";
import { 
  MapPin, 
  Mail, 
  Phone, 
  Calendar, 
  BookOpen, 
  Edit,
  Plus,
  Github,
  Linkedin
} from "lucide-react";
import { getProfile, createProfile, updateProfile, getMyProjectApplications, Profile as ProfileType } from "@/lib/api";

const Profile = () => {
  const { username } = useAuth();
  const [profile, setProfile] = useState<ProfileType | null>(null);
  const [applications, setApplications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [hasProfile, setHasProfile] = useState(false);

  const form = useForm({
    defaultValues: {
      fullName: "",
      college: "",
      phone: "",
      bio: "",
      skills: "",
      interests: "",
      achievements: "",
      projects: "",
      year: 1,
      branch: "",
      githubLink: "",
      linkedinLink: ""
    }
  });

  useEffect(() => {
    if (username) {
      loadProfileData();
    }
  }, [username]);

  const loadProfileData = async () => {
    try {
      setIsLoading(true);
      const profileData = await getProfile(username!);
      
      if (profileData) {
        setProfile(profileData);
        setHasProfile(true);
        // Populate form with existing data
        form.reset({
          fullName: profileData.fullName || "",
          college: profileData.college || "",
          phone: profileData.phone || "",
          bio: profileData.bio || "",
          skills: profileData.skills?.join(', ') || "",
          interests: profileData.interests?.join(', ') || "",
          achievements: profileData.achievements?.join(', ') || "",
          projects: profileData.projects?.join(', ') || "",
          year: profileData.year || 1,
          branch: profileData.branch || "",
          githubLink: profileData.githubLink || "",
          linkedinLink: profileData.linkedinLink || ""
        });
      } else {
        setHasProfile(false);
      }

      // Load applications
      const applicationsData = await getMyProjectApplications(username!);
      setApplications(applicationsData);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load profile data",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const onSubmit = async (data: any) => {
    try {
      const profileData = {
        username: username!,
        ...data,
        skills: data.skills ? data.skills.split(',').map(s => s.trim()) : [],
        interests: data.interests ? data.interests.split(',').map(s => s.trim()) : [],
        achievements: data.achievements ? data.achievements.split(',').map(s => s.trim()) : [],
        projects: data.projects ? data.projects.split(',').map(s => s.trim()) : [],
        year: parseInt(data.year) || 1
      };

      if (hasProfile) {
        await updateProfile(profileData);
        toast({
          title: "Success",
          description: "Profile updated successfully!"
        });
      } else {
        await createProfile(profileData);
        toast({
          title: "Success", 
          description: "Profile created successfully!"
        });
        setHasProfile(true);
      }

      setIsEditDialogOpen(false);
      loadProfileData();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save profile",
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-24 pb-8 px-4 max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded w-48 mb-4"></div>
            <div className="h-32 bg-muted rounded mb-6"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!hasProfile) {
    return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <Navigation />
      <div className="pt-24 pb-8 px-4 max-w-4xl mx-auto">
          <Card className="shadow-medium">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Complete Your Profile</CardTitle>
              <p className="text-muted-foreground">
                Let's set up your profile to get started with Campulse
              </p>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="college"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>College</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                     <FormField
                       control={form.control}
                       name="githubLink"
                       render={({ field }) => (
                         <FormItem>
                           <FormLabel>GitHub Profile</FormLabel>
                           <FormControl>
                             <Input {...field} placeholder="https://github.com/username" />
                           </FormControl>
                           <FormMessage />
                         </FormItem>
                       )}
                     />
                     <FormField
                       control={form.control}
                       name="linkedinLink"
                       render={({ field }) => (
                         <FormItem>
                           <FormLabel>LinkedIn Profile</FormLabel>
                           <FormControl>
                             <Input {...field} placeholder="https://linkedin.com/in/username" />
                           </FormControl>
                           <FormMessage />
                         </FormItem>
                       )}
                     />
                     <FormField
                       control={form.control}
                       name="branch"
                       render={({ field }) => (
                         <FormItem>
                           <FormLabel>Branch/Department</FormLabel>
                           <FormControl>
                             <Input {...field} />
                           </FormControl>
                           <FormMessage />
                         </FormItem>
                       )}
                     />
                    <FormField
                      control={form.control}
                      name="year"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Year of Study</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" min="1" max="5" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="bio"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Bio</FormLabel>
                        <FormControl>
                          <Textarea {...field} rows={3} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="skills"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Skills (comma separated)</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="React, Node.js, Python..." />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="interests"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Interests (comma separated)</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Web Development, AI, Startups..." />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="achievements"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Achievements (comma separated)</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Hackathon Winner, Dean's List..." />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="projects"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Projects (comma separated)</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="E-commerce App, Chat Bot..." />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full">
                    Create Profile
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <Navigation />
      
      <div className="pt-24 pb-8 px-4 max-w-6xl mx-auto">
        {/* Profile Header */}
        <Card className="mb-8 shadow-xl border-0 bg-gradient-to-br from-card to-card/80 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex flex-col items-center md:items-start">
                <Avatar className="h-28 w-28 mb-4 border-4 border-primary/20 shadow-lg">
                  <AvatarFallback className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground text-3xl">
                    {profile?.fullName?.split(' ').map(n => n[0]).join('') || username?.[0].toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-2 border-primary/20 hover:border-primary/40">
                      <Edit size={16} />
                      Edit Profile
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Edit Profile</DialogTitle>
                    </DialogHeader>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="fullName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Full Name</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="college"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>College</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="phone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Phone</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="githubLink"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>GitHub Profile</FormLabel>
                                <FormControl>
                                  <Input 
                                    {...field} 
                                    value={field.value || ''} 
                                    placeholder="https://github.com/username" 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="linkedinLink"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>LinkedIn Profile</FormLabel>
                                <FormControl>
                                  <Input 
                                    {...field} 
                                    value={field.value || ''} 
                                    placeholder="https://linkedin.com/in/username" 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="branch"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Branch/Department</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="year"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Year of Study</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1" max="5" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        <FormField
                          control={form.control}
                          name="bio"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Bio</FormLabel>
                              <FormControl>
                                <Textarea {...field} rows={3} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="skills"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Skills (comma separated)</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="React, Node.js, Python..." />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="interests"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Interests (comma separated)</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="Web Development, AI, Startups..." />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="achievements"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Achievements (comma separated)</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="Hackathon Winner, Dean's List..." />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="projects"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Projects (comma separated)</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="E-commerce App, Chat Bot..." />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="flex gap-2">
                          <Button type="submit" className="flex-1">Save Changes</Button>
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => setIsEditDialogOpen(false)}
                          >
                            Cancel
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>
              
              <div className="flex-1">
                <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                  {profile?.fullName || username}
                </h1>
                <p className="text-xl text-muted-foreground mb-1 font-medium">{profile?.branch} Student</p>
                <p className="text-sm text-muted-foreground bg-muted/30 px-3 py-1 rounded-full inline-block mb-4">
                  Year {profile?.year} • {profile?.college}
                </p>
                
                {profile?.bio && (
                  <div className="bg-gradient-to-r from-muted/20 to-muted/10 p-4 rounded-lg border border-muted/30 mb-4">
                    <p className="text-base leading-relaxed text-foreground/90">{profile.bio}</p>
                  </div>
                )}
                
                {/* Contact Info & Social Links */}
                <div className="flex flex-wrap gap-3 mb-4">
                  {profile?.phone && (
                    <div className="flex items-center gap-2 text-sm bg-muted/30 px-3 py-1 rounded-lg">
                      <Phone size={14} className="text-primary" />
                      <span>{profile.phone}</span>
                    </div>
                  )}
                  {profile?.githubLink && (
                    <Button variant="outline" size="sm" className="border-primary/20 hover:border-primary/40" asChild>
                      <a href={profile.githubLink} target="_blank" rel="noopener noreferrer">
                        <Github className="mr-2 h-4 w-4" />
                        GitHub
                      </a>
                    </Button>
                  )}
                  {profile?.linkedinLink && (
                    <Button variant="outline" size="sm" className="border-primary/20 hover:border-primary/40" asChild>
                      <a href={profile.linkedinLink} target="_blank" rel="noopener noreferrer">
                        <Linkedin className="mr-2 h-4 w-4" />
                        LinkedIn
                      </a>
                    </Button>
                  )}
                </div>
                
                {/* Skills */}
                {profile?.skills && profile.skills.length > 0 && (
                  <div className="bg-gradient-to-r from-primary/5 to-secondary/5 p-4 rounded-lg border border-primary/10 mb-4">
                    <h3 className="font-bold text-primary text-sm tracking-wider mb-3 flex items-center gap-2">
                      <BookOpen size={16} />
                      SKILLS
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {profile.skills.map((skill, index) => (
                        <Badge key={index} variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Interests */}
                {profile?.interests && profile.interests.length > 0 && (
                  <div className="bg-gradient-to-r from-secondary/5 to-primary/5 p-4 rounded-lg border border-secondary/10 mb-4">
                    <h3 className="font-bold text-secondary text-sm tracking-wider mb-3">INTERESTS</h3>
                    <div className="flex flex-wrap gap-2">
                      {profile.interests.map((interest, index) => (
                        <Badge key={index} variant="outline" className="border-secondary/30 text-secondary hover:bg-secondary/10">
                          {interest}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Achievements */}
                {profile?.achievements && profile.achievements.length > 0 && (
                  <div className="bg-gradient-to-r from-green-500/5 to-blue-500/5 p-4 rounded-lg border border-green-500/10 mb-4">
                    <h3 className="font-bold text-green-600 dark:text-green-400 text-sm tracking-wider mb-3">ACHIEVEMENTS</h3>
                    <div className="flex flex-wrap gap-2">
                      {profile.achievements.map((achievement, index) => (
                        <Badge key={index} variant="secondary" className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
                          {achievement}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Projects */}
                {profile?.projects && profile.projects.length > 0 && (
                  <div className="bg-gradient-to-r from-purple-500/5 to-pink-500/5 p-4 rounded-lg border border-purple-500/10">
                    <h3 className="font-bold text-purple-600 dark:text-purple-400 text-sm tracking-wider mb-3">PROJECTS</h3>
                    <div className="flex flex-wrap gap-2">
                      {profile.projects.map((project, index) => (
                        <Badge key={index} variant="outline" className="border-purple-300 text-purple-700 dark:border-purple-700 dark:text-purple-300 hover:bg-purple-50 dark:hover:bg-purple-900/20">
                          {project}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Applications */}
        {applications.length > 0 && (
          <Card className="shadow-medium">
            <CardHeader>
              <CardTitle>My Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {applications.map((app: any) => (
                  <div key={app.id} className="border rounded-lg p-4">
                    <h4 className="font-medium">{app.projectTitle}</h4>
                    <p className="text-sm text-muted-foreground">{app.role}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Profile;
