import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { toast } from "@/hooks/use-toast";
import { Search, Plus, Calendar, Rocket, Code, Users, User } from "lucide-react";
import { 
  getProjects, 
  createProject, 
  applyForProject, 
  getMyProjectApplications, 
  acceptProjectApplication, 
  deleteProject, 
  getAppliedProjects,
  type Project,
  type ProjectApplication
} from "@/lib/api";
import { ProfilePreview } from "@/components/ProfilePreview";

const Projects = () => {
  const { username } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [incomingRequests, setIncomingRequests] = useState<ProjectApplication[]>([]);
  const [appliedProjects, setAppliedProjects] = useState<string[]>([]);
  const [myApplications, setMyApplications] = useState<ProjectApplication[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [activeTab, setActiveTab] = useState<"all" | "applications" | "requests">("all");
  const [applyingProjects, setApplyingProjects] = useState<Set<string>>(new Set());

  const form = useForm({
    defaultValues: { title: "", description: "", technologies: "", teamName: "", maxTeamMembers: 5, category: "General" }
  });

  useEffect(() => {
    loadProjects();
    loadApplications();
  }, []);

  const loadProjects = async () => {
    try {
      setIsLoading(true);
      const data = await getProjects();
      setProjects(data);
    } catch (error) {
      toast({ title: "Error", description: "Failed to load projects", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const loadApplications = async () => {
    if (!username) return;
    try {
      // Get applications TO my projects (incoming requests)
      const requests = await getAppliedProjects(username);
      setIncomingRequests(requests);
      
      // Get my applications (applications I made to other projects)
      const myApps = await getMyProjectApplications(username);
      setMyApplications(myApps);
      setAppliedProjects(myApps.map(app => app.projectName || app.title));
    } catch (error) {
      console.error(error);
    }
  };

  const onCreateProject = async (data: any) => {
    try {
      await createProject({
        title: data.title,
        description: data.description,
        teamName: data.teamName || data.title,
        teamLead: username!,
        fullName: username!,
        date: new Date().toISOString().split('T')[0],
        maxTeamMembers: data.maxTeamMembers || 5,
        currentTeamMembers: 1,
        category: data.category || 'General',
        technologies: data.technologies ? data.technologies.split(",").map((t: string) => t.trim()) : []
      });
      toast({ title: "Success", description: "Project created!" });
      setIsCreateDialogOpen(false);
      form.reset();
      loadProjects();
    } catch (error) {
      toast({ title: "Error", description: "Failed to create project", variant: "destructive" });
    }
  };

  const handleApply = async (project: Project) => {
    if (!username || applyingProjects.has(project.title)) return;
    
    setApplyingProjects(prev => new Set(prev).add(project.title));
    
    try {
      await applyForProject({
        title: project.title,
        projectName: project.title,
        myUsername: username,
        username: project.teamLead,
        fullName: project.fullName || project.teamLead,
        description: project.description,
        technologies: project.technologies || [],
        accept: false,
        category: project.category
      });
      toast({ title: "Success", description: "Applied successfully!" });
      setAppliedProjects(prev => [...prev, project.title]);
      loadApplications(); // Refresh to get updated data
    } catch (error) {
      toast({ title: "Error", description: "Failed to apply", variant: "destructive" });
    } finally {
      setApplyingProjects(prev => {
        const newSet = new Set(prev);
        newSet.delete(project.title);
        return newSet;
      });
    }
  };

  const handleAcceptApplication = async (app: ProjectApplication) => {
    try {
      await acceptProjectApplication(app);
      toast({ 
        title: "Success", 
        description: `${app.myUsername} accepted! They can now join the project chat group.` 
      });
      loadApplications();
      loadProjects(); // Refresh to update team member count
    } catch (error) {
      toast({ title: "Error", description: "Failed to accept", variant: "destructive" });
    }
  };

  const handleDeleteProject = async (id?: number) => {
    if (!id) return;
    try {
      await deleteProject(id);
      toast({ title: "Deleted", description: "Project deleted successfully" });
      loadProjects();
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete project", variant: "destructive" });
    }
  };

  const filteredProjects = projects.filter(project => 
    project.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.technologies?.some(tech => tech.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const getProjectIcon = () => <Code className="text-blue-600" size={20} />;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-24 pb-8 px-4 max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded w-48 mb-4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1,2,3,4,5,6].map(i => <div key={`skeleton-${i}`} className="h-80 bg-muted rounded-lg"></div>)}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-24 pb-8 px-4 max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-1">Project Hub</h1>
            <p className="text-muted-foreground">Discover or share projects</p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <Button onClick={() => setIsCreateDialogOpen(true)} className="gap-2">
              <Plus size={18}/> Create Project
            </Button>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Project</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onCreateProject)} className="space-y-4">
                  <FormField control={form.control} name="title" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Project Title</FormLabel>
                      <FormControl><Input {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}/>
                  <FormField control={form.control} name="teamName" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team/Group Name</FormLabel>
                      <FormControl><Input {...field} placeholder="Enter team name for chat group" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}/>
                  <FormField control={form.control} name="description" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl><Textarea {...field} rows={3}/></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}/>
                  <FormField control={form.control} name="technologies" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Technologies (comma separated)</FormLabel>
                      <FormControl><Input {...field} placeholder="React, Node.js, MongoDB..." /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}/>
                  <div className="grid grid-cols-2 gap-4">
                    <FormField control={form.control} name="category" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <FormControl><Input {...field} placeholder="Web Development" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}/>
                    <FormField control={form.control} name="maxTeamMembers" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Max Team Size</FormLabel>
                        <FormControl><Input {...field} type="number" min="1" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}/>
                  </div>
                  <div className="flex gap-2">
                    <Button type="submit" className="flex-1">Create Project</Button>
                    <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>Cancel</Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-6">
          <Button variant={activeTab === "all" ? "default" : "outline"} onClick={() => setActiveTab("all")}>All Projects</Button>
          <Button variant={activeTab === "applications" ? "default" : "outline"} onClick={() => setActiveTab("applications")}>
            My Applications ({myApplications.length})
          </Button>
          <Button variant={activeTab === "requests" ? "default" : "outline"} onClick={() => setActiveTab("requests")}>
            Requests ({incomingRequests.filter(a => !a.accept).length})
          </Button>
        </div>

        {/* Search */}
        <div className="relative flex-1 max-w-md mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
          <Input
            placeholder="Search projects..."
            className="pl-10"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>

        {/* Tab Content */}
        {activeTab === "all" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.length === 0 ? (
              <Card className="text-center p-8">
                <Rocket size={48} className="mx-auto text-muted-foreground mb-4"/>
                <p className="text-muted-foreground">No projects found</p>
              </Card>
            ) : filteredProjects.map(project => (
              <Card key={project.id} className="shadow-soft hover:shadow-medium transition-all duration-200 flex flex-col border-primary/10">
                <CardHeader className="pb-3 bg-gradient-to-br from-primary/5 to-primary/10">
                  <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                      <CardTitle className="text-xl font-bold mb-2 text-foreground">{project.title}</CardTitle>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                        <User size={14} className="text-primary"/>
                        <ProfilePreview username={project.teamLead}>
                          <span className="hover:text-primary cursor-pointer transition-colors">
                            {project.fullName}
                          </span>
                        </ProfilePreview>
                      </div>
                      <Badge className="bg-primary/10 text-primary hover:bg-primary/20">{project.category}</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 space-y-3 pt-4">
                  <p className="text-sm text-foreground leading-relaxed line-clamp-3">{project.description}</p>
                  
                  <div className="flex flex-col gap-2 text-xs">
                    <div className="flex items-center gap-2 text-muted-foreground bg-muted/50 p-2 rounded-md">
                      <Calendar size={14} className="text-primary"/>
                      <span>{new Date(project.date).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground bg-muted/50 p-2 rounded-md">
                      <Users size={14} className="text-primary"/>
                      <span>{project.currentTeamMembers || 0} / {project.maxTeamMembers} members</span>
                    </div>
                  </div>
                  
                  {project.technologies && project.technologies.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.slice(0, 4).map((tech, i) => (
                        <Badge key={i} variant="outline" className="text-xs border-primary/30 text-primary">
                          {tech}
                        </Badge>
                      ))}
                      {project.technologies.length > 4 && (
                        <Badge variant="outline" className="text-xs border-primary/30 text-primary">
                          +{project.technologies.length - 4}
                        </Badge>
                      )}
                    </div>
                  )}
                </CardContent>
                <CardFooter className="pt-3 border-t">
                  {project.teamLead !== username ? (
                    <Button 
                      onClick={() => handleApply(project)} 
                      className="w-full bg-gradient-primary text-white hover:opacity-90"
                      size="sm"
                      disabled={appliedProjects.includes(project.title) || applyingProjects.has(project.title)}
                    >
                      {applyingProjects.has(project.title) ? "Applying..." : appliedProjects.includes(project.title) ? "Applied ✓" : "Apply to Project"}
                    </Button>
                  ) : (
                    <div className="flex gap-2 w-full">
                      <Badge className="flex-1 justify-center bg-primary/10 text-primary border-primary/20 py-2">Your Project</Badge>
                      <Button size="sm" variant="destructive" onClick={() => handleDeleteProject(project.id)}>Delete</Button>
                    </div>
                  )}
                </CardFooter>
              </Card>
            ))}
          </div>
        )}

        {activeTab === "applications" && (
          <div>
            {myApplications.length === 0 ? (
              <p className="text-muted-foreground">No applications found</p>
            ) : myApplications.map(app => (
              <Card key={app.id} className="mb-4">
                <CardContent className="flex justify-between items-center p-6">
                  <div>
                    <p className="font-semibold">{app.projectName}</p>
                    <p className="text-sm text-muted-foreground mt-1">{app.description}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {app.technologies?.map((tech, i) => (
                        <Badge key={i} variant="outline" className="text-xs">{tech}</Badge>
                      ))}
                    </div>
                  </div>
                  {app.accept ? <Badge variant="secondary">Accepted</Badge> : <Badge variant="outline">Pending</Badge>}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {activeTab === "requests" && (
          <div>
            {incomingRequests.filter(a => !a.accept).length === 0 ? (
              <p className="text-muted-foreground">No pending requests found</p>
            ) : incomingRequests.filter(a => !a.accept).map(app => (
              <Card key={app.id} className="mb-4 shadow-soft hover:shadow-medium transition-all">
                <CardContent className="flex justify-between items-center p-6">
                  <div className="flex-1">
                    <p className="font-semibold text-lg">{app.projectName}</p>
                    <div className="flex items-center gap-2 text-sm mt-1">
                      <span className="text-muted-foreground">Applied by:</span>
                      <ProfilePreview username={app.myUsername} asDialog>
                        <span className="text-primary font-semibold cursor-pointer hover:underline">
                          {app.myUsername}
                        </span>
                      </ProfilePreview>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">{app.description}</p>
                    <div className="flex flex-wrap gap-1 mt-3">
                      {app.technologies?.map((tech, i) => (
                        <Badge key={i} variant="outline" className="text-xs border-primary/30">{tech}</Badge>
                      ))}
                    </div>
                  </div>
                  <div className="ml-4">
                    <Button size="sm" onClick={() => handleAcceptApplication(app)} className="bg-green-600 hover:bg-green-700 text-white">
                      Accept
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Project Detail Modal */}
        <Dialog open={!!selectedProject} onOpenChange={open => !open && setSelectedProject(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            {selectedProject && (
              <>
                <DialogHeader><DialogTitle>{selectedProject.title}</DialogTitle></DialogHeader>
                <CardContent>
                  <p><strong>Team/Group Name:</strong> {selectedProject.teamName}</p>
                  <p><strong>Team Lead:</strong> {selectedProject.fullName} ({selectedProject.teamLead})</p>
                  <p><strong>Category:</strong> {selectedProject.category}</p>
                  <p><strong>Team Size:</strong> {selectedProject.currentTeamMembers || 0}/{selectedProject.maxTeamMembers}</p>
                  <p><strong>Date:</strong> {new Date(selectedProject.date).toLocaleDateString()}</p>
                  <p className="mt-2">{selectedProject.description}</p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {selectedProject.technologies.map((tech, i) => <Badge key={i} variant="outline">{tech}</Badge>)}
                  </div>
                </CardContent>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default Projects;
