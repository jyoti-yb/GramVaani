import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { toast } from "@/hooks/use-toast";
import { Lightbulb, Plus, MessageSquare, Trash2, Loader2, Send } from "lucide-react";
import { 
  addIdea, 
  getAllIdeas, 
  deleteIdea, 
  addValidationComment, 
  getCommentsByTitle,
  deleteValidationComment,
  type Idea,
  type ValidateComment
} from "@/lib/api";
import { ProfilePreview } from "@/components/ProfilePreview";

const ProjectIdeas = () => {
  const { username } = useAuth();
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [selectedIdea, setSelectedIdea] = useState<Idea | null>(null);
  const [comments, setComments] = useState<ValidateComment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newComment, setNewComment] = useState("");

  const form = useForm({
    defaultValues: { title: "", description: "" }
  });

  useEffect(() => {
    loadIdeas();
  }, []);

  const loadIdeas = async () => {
    try {
      setIsLoading(true);
      const data = await getAllIdeas();
      setIdeas(data);
    } catch (error) {
      toast({ title: "Error", description: "Failed to load ideas", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const loadComments = async (title: string) => {
    try {
      const data = await getCommentsByTitle(title);
      setComments(data);
    } catch (error) {
      console.error(error);
    }
  };

  const onCreateIdea = async (data: any) => {
    try {
      await addIdea({
        title: data.title,
        description: data.description,
        teamLead: username!,
        fullName: username!,
        date: new Date().toISOString().split('T')[0]
      });
      toast({ title: "Success", description: "Idea posted!" });
      setIsCreateDialogOpen(false);
      form.reset();
      loadIdeas();
    } catch (error) {
      toast({ title: "Error", description: "Failed to post idea", variant: "destructive" });
    }
  };

  const handleDeleteIdea = async (title: string) => {
    try {
      await deleteIdea(title);
      toast({ title: "Deleted", description: "Idea deleted successfully" });
      loadIdeas();
      setSelectedIdea(null);
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete idea", variant: "destructive" });
    }
  };

  const handleAddComment = async () => {
    if (!newComment.trim() || !selectedIdea || !username) return;
    try {
      await addValidationComment({
        title: selectedIdea.title,
        comment: newComment,
        username
      });
      toast({ title: "Success", description: "Comment added!" });
      setNewComment("");
      loadComments(selectedIdea.title);
    } catch (error) {
      toast({ title: "Error", description: "Failed to add comment", variant: "destructive" });
    }
  };

  const handleDeleteComment = async (id: number) => {
    try {
      await deleteValidationComment(id);
      toast({ title: "Deleted", description: "Comment deleted" });
      if (selectedIdea) loadComments(selectedIdea.title);
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete comment", variant: "destructive" });
    }
  };

  const handleViewIdea = async (idea: Idea) => {
    setSelectedIdea(idea);
    await loadComments(idea.title);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-24 pb-8 px-4 max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded w-48 mb-4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1,2,3,4,5,6].map(i => <div key={i} className="h-64 bg-muted rounded-lg"></div>)}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-24 pb-8 px-4 max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-1 flex items-center gap-2">
              <Lightbulb className="text-primary" size={32} />
              Project Ideas
            </h1>
            <p className="text-muted-foreground">Share and validate project ideas with the community</p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <Button onClick={() => setIsCreateDialogOpen(true)} className="gap-2 bg-gradient-primary">
              <Plus size={18}/> Post Idea
            </Button>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Share Your Project Idea</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onCreateIdea)} className="space-y-4">
                  <FormField control={form.control} name="title" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl><Input {...field} placeholder="My awesome project idea..." /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}/>
                  <FormField control={form.control} name="description" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl><Textarea {...field} rows={4} placeholder="Describe your idea in detail..." /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}/>
                  <div className="flex gap-2">
                    <Button type="submit" className="flex-1 bg-gradient-primary">Post Idea</Button>
                    <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>Cancel</Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Ideas Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {ideas.length === 0 ? (
            <Card className="text-center p-8 col-span-full shadow-soft">
              <Lightbulb size={48} className="mx-auto text-primary mb-4"/>
              <p className="text-muted-foreground">No ideas yet. Be the first to share!</p>
            </Card>
          ) : ideas.map(idea => (
            <Card 
              key={idea.id} 
              className="shadow-soft hover:shadow-medium transition-all cursor-pointer border-primary/10 relative" 
              onClick={() => handleViewIdea(idea)}
            >
              <CardHeader className="bg-gradient-to-br from-primary/5 to-primary/10">
                <CardTitle className="text-lg flex items-start justify-between gap-2">
                  <span className="text-foreground">{idea.title}</span>
                  <div className="flex items-center gap-2">
                    <Lightbulb size={20} className="text-primary flex-shrink-0" />
                    {idea.teamLead === username && (
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-6 w-6 p-0 text-destructive hover:bg-destructive/10"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteIdea(idea.title);
                        }}
                      >
                        <Trash2 size={14} />
                      </Button>
                    )}
                  </div>
                </CardTitle>
                <div className="flex items-center gap-1">
                  <ProfilePreview username={idea.teamLead}>
                    <p className="text-sm font-medium text-primary hover:underline cursor-pointer">
                      {idea.fullName}
                    </p>
                  </ProfilePreview>
                </div>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <span>📅</span> {new Date(idea.date).toLocaleDateString()}
                </p>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-foreground leading-relaxed line-clamp-3 mb-4">{idea.description}</p>
                <Button size="sm" variant="outline" className="w-full gap-2 border-primary/30 text-primary hover:bg-primary/10">
                  <MessageSquare size={16} />
                  View & Comment
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Idea Detail Dialog */}
        <Dialog open={!!selectedIdea} onOpenChange={open => !open && setSelectedIdea(null)}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            {selectedIdea && (
              <>
                <DialogHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <DialogTitle className="text-2xl mb-1">{selectedIdea.title}</DialogTitle>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>By</span>
                        <ProfilePreview username={selectedIdea.teamLead}>
                          <span className="font-medium text-primary hover:underline cursor-pointer">
                            {selectedIdea.fullName}
                          </span>
                        </ProfilePreview>
                        <span>•</span>
                        <span>{new Date(selectedIdea.date).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </DialogHeader>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="font-semibold mb-2">Description</h3>
                    <p className="text-muted-foreground">{selectedIdea.description}</p>
                  </div>

                  <div className="border-t pt-4">
                    <h3 className="font-semibold mb-4 flex items-center gap-2 text-primary">
                      <MessageSquare size={18} />
                      Feedback & Validation ({comments.length})
                    </h3>
                    
                    <div className="space-y-3 mb-4 max-h-60 overflow-y-auto">
                      {comments.length === 0 ? (
                        <p className="text-sm text-muted-foreground text-center py-4">No feedback yet. Be the first to comment!</p>
                      ) : (
                        comments.map(comment => (
                          <div key={comment.id} className="bg-gradient-to-br from-primary/5 to-primary/10 p-3 rounded-lg border border-primary/10 relative group">
                            {comment.username ? (
                              <ProfilePreview username={comment.username}>
                                <p className="text-xs font-semibold text-primary mb-1 hover:underline cursor-pointer">
                                  {comment.username}
                                </p>
                              </ProfilePreview>
                            ) : (
                              <p className="text-xs font-semibold text-muted-foreground mb-1">Anonymous</p>
                            )}
                            <p className="text-sm text-foreground pr-8">{comment.comment}</p>
                            {username && comment.username === username && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="absolute top-2 right-2 h-6 w-6 p-0 text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-opacity"
                                onClick={() => handleDeleteComment(comment.id!)}
                              >
                                <Trash2 size={12} />
                              </Button>
                            )}
                          </div>
                        ))
                      )}
                    </div>

                    <div className="flex gap-2">
                      <Input
                        placeholder="Add your feedback..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAddComment()}
                        className="flex-1"
                      />
                      <Button onClick={handleAddComment} size="sm" className="bg-gradient-primary text-white">
                        <Send size={16} />
                      </Button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default ProjectIdeas;
