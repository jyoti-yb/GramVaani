import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Share2, Loader2 } from 'lucide-react';

const Signup = () => {
  const [formData, setFormData] = useState({
    username: '',
    fullName: '',
    email: '',
    password: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const { signup } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();

  // Username validation
  const usernameRegex = /^2\d{9}$/;
  if (!usernameRegex.test(formData.username)) {
    toast({
      title: "Invalid Username",
      description: "Username must be a 10-digit number starting with 2.",
      variant: "destructive",
    });
    return;
  }

  // Email validation
  const emailRegex = /^[a-zA-Z0-9._%+-]+@kluniversity\.in$/;
  if (!emailRegex.test(formData.email)) {
    toast({
      title: "Invalid Email",
      description: "Email must be a valid KL University email (@kluniversity.in).",
      variant: "destructive",
    });
    return;
  }

  // Password validation
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  if (!passwordRegex.test(formData.password)) {
    toast({
      title: "Weak Password",
      description: "Password must be at least 8 characters long, include uppercase, lowercase, number, and special character.",
      variant: "destructive",
    });
    return;
  }

  setIsLoading(true);
  try {
    const result = await signup({
      username: formData.username,
      fullName: formData.fullName,
      email: formData.email,
      password: formData.password,
    });

    if (result.includes("successful")) {
      toast({
        title: "Account Created",
        description: "Your account has been created successfully. Please sign in.",
      });
      navigate("/login");
    } else {
      toast({
        title: "Signup Failed",
        description: result,
        variant: "destructive",
      });
    }
  } catch (error) {
    toast({
      title: "Error",
      description: "An unexpected error occurred. Please try again.",
      variant: "destructive",
    });
  } finally {
    setIsLoading(false);
  }
};


  return (
    <div className="min-h-screen bg-gradient-primary flex items-center justify-center p-8">
      <div className="w-full max-w-md">
        <Card className="bg-white shadow-2xl border-0">
          <CardContent className="p-8">
            {/* Logo */}
            <div className="flex items-center justify-center space-x-3 mb-8">
              <Share2 className="h-8 w-8 text-primary" />
              <span className="text-2xl font-bold text-primary">Campulse</span>
            </div>

            {/* Header */}
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-2">Join Campulse</h2>
              <p className="text-muted-foreground">Create your account and start collaborating with fellow students</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-sm font-medium">Username</Label>
                <Input
                  id="username"
                  name="username"
                  type="text"
                  placeholder="Choose a unique username"
                  value={formData.username}
                  onChange={handleChange}
                  disabled={isLoading}
                  className="h-12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="fullName" className="text-sm font-medium">Full Name</Label>
                <Input
                  id="fullName"
                  name="fullName"
                  type="text"
                  placeholder="Enter your full name"
                  value={formData.fullName}
                  onChange={handleChange}
                  disabled={isLoading}
                  className="h-12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="Enter your email address"
                  value={formData.email}
                  onChange={handleChange}
                  disabled={isLoading}
                  className="h-12"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">Password</Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="Create a strong password"
                  value={formData.password}
                  onChange={handleChange}
                  disabled={isLoading}
                  className="h-12"
                />
              </div>

              <Button 
                type="submit" 
                className="w-full h-12 bg-gradient-primary text-white hover:opacity-90 text-base font-medium"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  'Create Account'
                )}
              </Button>
            </form>

            <div className="mt-8 text-center">
              <p className="text-sm text-muted-foreground">
                Already have an account?{' '}
                <Link to="/login" className="text-primary hover:underline font-medium">
                  Sign in here
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Signup;
