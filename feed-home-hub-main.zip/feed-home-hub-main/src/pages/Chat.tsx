import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Send, MessageCircle, Users } from "lucide-react";
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { 
  getChatHistory, 
  getProjects, 
  getAppliedProjects,
  type ChatMessage,
  type Project 
} from "@/lib/api";

const Chat = () => {
  const { username } = useAuth();
  const [groupName, setGroupName] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const [joined, setJoined] = useState(false);
  const [availableGroups, setAvailableGroups] = useState<string[]>([]);
  const [showGroups, setShowGroups] = useState(true);
  const stompClientRef = useRef<Client | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    loadAvailableGroups();
  }, [username]);

  const loadAvailableGroups = async () => {
    if (!username) return;
    try {
      // Get projects where user is team lead
      const allProjects = await getProjects();
      const myProjects = allProjects.filter(p => p.teamLead === username);
      
      // Get projects where user's application was accepted
      const myApplications = await getAppliedProjects(username);
      const acceptedApps = myApplications.filter(app => app.accept);
      
      // Get team names from both sources
      const myTeamNames = myProjects.map(p => p.teamName).filter(Boolean);
      const acceptedTeamNames = acceptedApps.map(app => {
        const project = allProjects.find(p => p.title === app.projectName);
        return project?.teamName;
      }).filter(Boolean);
      
      const uniqueGroups = Array.from(new Set([...myTeamNames, ...acceptedTeamNames]));
      setAvailableGroups(uniqueGroups as string[]);
    } catch (error) {
      console.error('Failed to load available groups:', error);
    }
  };

  const connect = () => {
    const socket = new SockJS('http://localhost:8081/ws-chat');
    const client = new Client({
      webSocketFactory: () => socket as any,
      onConnect: () => {
        setIsConnected(true);
        toast({ title: "Connected", description: "Connected to chat server" });
        
        client.subscribe('/topic/group', (message) => {
          const chatMessage = JSON.parse(message.body);
          setMessages(prev => [...prev, chatMessage]);
        });
      },
      onDisconnect: () => {
        setIsConnected(false);
        toast({ title: "Disconnected", description: "Disconnected from chat server" });
      },
      onStompError: (frame) => {
        console.error('STOMP error:', frame);
        toast({ title: "Error", description: "Connection error", variant: "destructive" });
      }
    });

    client.activate();
    stompClientRef.current = client;
  };

  const disconnect = () => {
    if (stompClientRef.current) {
      stompClientRef.current.deactivate();
      setIsConnected(false);
      setJoined(false);
      setMessages([]);
      setShowGroups(true);
    }
  };

  const joinGroup = async (selectedGroup?: string) => {
    const groupToJoin = selectedGroup || groupName;
    
    if (!groupToJoin.trim()) {
      toast({ title: "Error", description: "Please enter a group name", variant: "destructive" });
      return;
    }

    try {
      if (!isConnected) {
        await new Promise((resolve) => {
          connect();
          setTimeout(resolve, 1000); // Wait for connection
        });
      }
      
      // Load chat history
      const history = await getChatHistory(groupToJoin);
      setMessages(history);
      
      // Send join message
      if (stompClientRef.current && isConnected) {
        const joinMessage: ChatMessage = {
          groupName: groupToJoin,
          sender: username!,
          content: `${username} joined the chat`,
          messageType: 'JOIN',
          timestamp: new Date().toISOString()
        };
        
        stompClientRef.current.publish({
          destination: '/app/chat.sendMessage',
          body: JSON.stringify(joinMessage)
        });
        
        setGroupName(groupToJoin);
        setJoined(true);
        setShowGroups(false);
        toast({ title: "Joined", description: `Joined ${groupToJoin}` });
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to join group", variant: "destructive" });
    }
  };

  const sendMessage = () => {
    if (!newMessage.trim() || !stompClientRef.current || !isConnected || !joined) return;

    const chatMessage: ChatMessage = {
      groupName,
      sender: username!,
      content: newMessage,
      messageType: 'CHAT',
      timestamp: new Date().toISOString()
    };

    stompClientRef.current.publish({
      destination: '/app/chat.sendMessage',
      body: JSON.stringify(chatMessage)
    });

    setNewMessage("");
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-24 pb-8 px-4 max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-1 flex items-center gap-2">
            <MessageCircle className="text-primary" size={32} />
            Group Chat
          </h1>
          <p className="text-muted-foreground">Real-time collaboration with your team</p>
        </div>

        {!joined ? (
          <div className="space-y-4">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Connect to a Group</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter group name..."
                    value={groupName}
                    onChange={(e) => setGroupName(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && joinGroup()}
                  />
                  <Button onClick={() => joinGroup()} className="bg-gradient-primary">
                    Join Group
                  </Button>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={isConnected ? "secondary" : "outline"}>
                    {isConnected ? "Connected" : "Disconnected"}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {availableGroups.length > 0 && (
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users size={20} className="text-primary" />
                    Your Project Groups
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {availableGroups.map((group, idx) => (
                      <Card key={idx} className="cursor-pointer hover:shadow-md transition-shadow border-2 border-muted" onClick={() => joinGroup(group)}>
                        <CardContent className="p-4 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Users size={18} className="text-primary" />
                            <span className="font-semibold">{group}</span>
                          </div>
                          <Button size="sm" variant="outline">Join</Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <Card className="shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>{groupName}</CardTitle>
                  <p className="text-sm text-muted-foreground">{messages.length} messages</p>
                </div>
                <Button variant="outline" size="sm" onClick={disconnect}>
                  Leave
                </Button>
              </CardHeader>
              <CardContent>
                <div className="h-96 overflow-y-auto mb-4 space-y-3 p-4 bg-muted/20 rounded-lg">
                  {messages.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`flex ${msg.sender === username ? 'justify-end' : 'justify-start'}`}
                    >
                      {msg.messageType === 'CHAT' ? (
                        <div className={`max-w-[70%] ${msg.sender === username ? 'bg-primary text-primary-foreground' : 'bg-muted'} rounded-lg p-3`}>
                          <p className="text-xs font-semibold mb-1">{msg.sender}</p>
                          <p className="text-sm">{msg.content}</p>
                          <p className="text-xs opacity-70 mt-1">
                            {new Date(msg.timestamp).toLocaleTimeString()}
                          </p>
                        </div>
                      ) : (
                        <Badge variant="outline" className="text-xs">
                          {msg.content}
                        </Badge>
                      )}
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>

                <div className="flex gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                  />
                  <Button onClick={sendMessage} size="icon" className="bg-gradient-primary">
                    <Send size={18} />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default Chat;
