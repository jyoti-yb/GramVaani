const API_BASE_URL = 'http://localhost:8081';

// =============== TYPES ===============
export interface User {
  username: string;
  password: string;
  email: string;
  fullName: string;
}

export interface Profile {
  username: string;
  fullName: string;
  branch: string;
  college: string;
  year: number;
  phone: string;
  githubLink: string;
  linkedinLink: string;
  bio: string;
  projects?: string[];
  skills?: string[];
  interests?: string[];
  achievements?: string[];
}

export interface Feed {
  id?: number;
  title: string;
  description: string;
  username: string;
  department: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface FeedComment {
  num?: number;
  feedId: number;
  comment: string;
  username?: string;
}

export interface Project {
  id?: number;
  title: string;
  teamName: string;
  teamLead: string;
  fullName: string;
  description: string;
  date: string;
  maxTeamMembers: number;
  currentTeamMembers?: number;
  category: string;
  technologies: string[];
}

export interface ProjectApplication {
  id?: number;
  title: string;
  myUsername: string;
  username: string;
  fullName: string;
  projectName: string;
  description: string;
  technologies: string[];
  accept: boolean;
  category: string;
}

export interface Idea {
  id?: number;
  title: string;
  teamLead: string;
  description: string;
  fullName: string;
  date: string;
}

export interface ValidateComment {
  id?: number;
  title: string;
  comment: string;
  username?: string;
}

export interface MiscProject {
  id?: number;
  teamName: string;
  teamLead: string;
  maxSize: number;
  currentSize: number;
}

export interface MiscProjectApplication {
  id?: number;
  teamName: string;
  teamLead: string;
  applicant: string;
  accepted: boolean;
}

export interface ChatMessage {
  groupName: string;
  sender: string;
  content: string;
  messageType: 'CHAT' | 'JOIN' | 'LEAVE';
  timestamp: string;
}

export interface TeamMember {
  username: string;
  fullName: string;
  branch: string;
  skills: string[];
}

export interface TeamApplication {
  id?: number;
  myUsername: string;
  username: string;
  fullName: string;
  branch: string;
  skills: string[];
}

// =============== USER APIs ===============
export const signup = async (userData: User): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/user/signup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(userData),
  });
  if (!response.ok) throw new Error('Signup failed');
  return await response.text();
};

export const login = async (credentials: { username: string; password: string }): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/user/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(credentials),
  });
  if (!response.ok) throw new Error('Login failed');
  const result = await response.text();
  if (result.includes('successful')) {
    localStorage.setItem('username', credentials.username);
  }
  return result;
};

export const forgetPassword = async (username: string): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/user/forget-password/${username}`, {
    method: 'POST',
  });
  if (!response.ok) throw new Error('Password recovery failed');
  return await response.text();
};

export const logout = (): void => {
  localStorage.removeItem('username');
};

export const getStoredUsername = (): string | null => {
  return localStorage.getItem('username');
};

// =============== FEED APIs ===============
export const createFeed = async (feedData: Omit<Feed, 'id'>): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/feed/feed`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(feedData),
  });
  if (!response.ok) throw new Error('Failed to create feed');
  return await response.text();
};

export const updateFeed = async (feedData: Feed): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/feed/feed`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(feedData),
  });
  if (!response.ok) throw new Error('Failed to update feed');
  return await response.text();
};

export const deleteFeed = async (id: number): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/feed/feed/${id}`, {
    method: 'DELETE',
  });
  if (!response.ok) throw new Error('Failed to delete feed');
  return await response.text();
};

export const getAllFeeds = async (): Promise<Feed[]> => {
  const response = await fetch(`${API_BASE_URL}/feed/feeds`);
  if (!response.ok) throw new Error('Failed to fetch feeds');
  return await response.json();
};

export const getFeedsByUsername = async (username: string): Promise<Feed[]> => {
  const response = await fetch(`${API_BASE_URL}/feed/feeds/${username}`);
  if (!response.ok) throw new Error('Failed to fetch user feeds');
  return await response.json();
};

// =============== FEED COMMENTS APIs ===============
export const addFeedComment = async (commentData: Omit<FeedComment, 'num'>): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/feed/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(commentData),
  });
  if (!response.ok) throw new Error('Failed to add comment');
  return await response.text();
};

export const getFeedComments = async (feedId: number): Promise<FeedComment[]> => {
  const response = await fetch(`${API_BASE_URL}/feed/comments/${feedId}`);
  if (!response.ok) return [];
  return await response.json();
};

export const deleteFeedComment = async (num: number): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/feed/comments/${num}`, {
    method: 'DELETE',
  });
  if (!response.ok) throw new Error('Failed to delete comment');
  return await response.text();
};

// =============== PROFILE APIs ===============
export const createProfile = async (profileData: Profile): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/profile/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(profileData),
  });
  if (!response.ok) throw new Error('Failed to create profile');
  return await response.text();
};

export const updateProfile = async (profileData: Profile): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/profile/`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(profileData),
  });
  if (!response.ok) throw new Error('Failed to update profile');
  return await response.text();
};

export const getProfile = async (username: string): Promise<Profile | null> => {
  try {
    const response = await fetch(`${API_BASE_URL}/profile/${username}`);
    if (!response.ok) return null;
    return await response.json();
  } catch (error) {
    return null;
  }
};

// =============== PROJECT APIs ===============
export const createProject = async (projectData: Omit<Project, 'id'>): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/project/project`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(projectData),
  });
  if (!response.ok) throw new Error('Failed to create project');
  return await response.text();
};

export const deleteProject = async (id: number): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/project/project/${id}`, {
    method: 'DELETE',
  });
  if (!response.ok) throw new Error('Failed to delete project');
  return await response.text();
};

export const getProjects = async (): Promise<Project[]> => {
  const response = await fetch(`${API_BASE_URL}/project/projects`);
  if (!response.ok) throw new Error('Failed to fetch projects');
  return await response.json();
};

export const applyForProject = async (applicationData: ProjectApplication): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/project/project/apply`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(applicationData),
  });
  if (!response.ok) throw new Error('Failed to apply for project');
  return await response.text();
};

export const getAppliedProjects = async (myUserName: string): Promise<ProjectApplication[]> => {
  const response = await fetch(`${API_BASE_URL}/project/project/applied/${myUserName}`);
  if (!response.ok) return [];
  return await response.json();
};

export const getMyProjectApplications = async (username: string): Promise<ProjectApplication[]> => {
  const response = await fetch(`${API_BASE_URL}/project/project/my-applications/${username}`);
  if (!response.ok) throw new Error('Failed to fetch project applications');
  return await response.json();
};

export const acceptProjectApplication = async (applicationData: ProjectApplication): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/project/project/accept`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...applicationData, accept: true }),
  });
  if (!response.ok) throw new Error('Failed to accept application');
  return await response.text();
};

// =============== PROJECT IDEAS APIs ===============
export const addIdea = async (ideaData: Omit<Idea, 'id'>): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/project/idea`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(ideaData),
  });
  if (!response.ok) throw new Error('Failed to add idea');
  return await response.text();
};

export const getAllIdeas = async (): Promise<Idea[]> => {
  const response = await fetch(`${API_BASE_URL}/project/ideas`);
  if (!response.ok) return [];
  return await response.json();
};

export const getIdeaByTitle = async (title: string): Promise<Idea | null> => {
  const response = await fetch(`${API_BASE_URL}/project/idea/${title}`);
  if (!response.ok) return null;
  return await response.json();
};

export const deleteIdea = async (title: string): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/project/idea/${title}`, {
    method: 'DELETE',
  });
  if (!response.ok) throw new Error('Failed to delete idea');
  return await response.text();
};

export const addValidationComment = async (commentData: ValidateComment): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/project/comment`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(commentData),
  });
  if (!response.ok) throw new Error('Failed to add comment');
  return await response.text();
};

export const getCommentsByTitle = async (title: string): Promise<ValidateComment[]> => {
  const response = await fetch(`${API_BASE_URL}/project/comments/${title}`);
  if (!response.ok) return [];
  return await response.json();
};

export const deleteValidationComment = async (id: number): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/project/comment/${id}`, {
    method: 'DELETE',
  });
  if (!response.ok) throw new Error('Failed to delete comment');
  return await response.text();
};

// =============== MISCELLANEOUS PROJECT APIs ===============
export const createMiscProject = async (projectData: Omit<MiscProject, 'id'>): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/project/misc/project`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(projectData),
  });
  if (!response.ok) throw new Error('Failed to create miscellaneous project');
  return await response.text();
};

export const getAllMiscProjects = async (): Promise<MiscProject[]> => {
  const response = await fetch(`${API_BASE_URL}/project/misc/projects`);
  if (!response.ok) return [];
  return await response.json();
};

export const applyToMiscProject = async (applicationData: Omit<MiscProjectApplication, 'id'>): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/project/misc/project/apply`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(applicationData),
  });
  if (!response.ok) throw new Error('Failed to apply to miscellaneous project');
  return await response.text();
};

export const getMiscProjectApplications = async (teamName: string): Promise<MiscProjectApplication[]> => {
  const response = await fetch(`${API_BASE_URL}/project/misc/project/applications/${teamName}`);
  if (!response.ok) return [];
  return await response.json();
};

export const acceptMiscProjectApplicant = async (applicationId: number): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/project/misc/project/accept/${applicationId}`, {
    method: 'POST',
  });
  if (!response.ok) throw new Error('Failed to accept applicant');
  return await response.text();
};

// =============== CHAT APIs ===============
export const getChatHistory = async (groupName: string): Promise<ChatMessage[]> => {
  const response = await fetch(`${API_BASE_URL}/chat/${groupName}`);
  if (!response.ok) return [];
  return await response.json();
};

export const getGroupMembers = async (groupName: string): Promise<any[]> => {
  const response = await fetch(`${API_BASE_URL}/project/group/members/${groupName}`);
  if (!response.ok) return [];
  return await response.json();
};

// =============== TEAM APIs ===============
export const getTeamMembers = async (): Promise<TeamMember[]> => {
  const response = await fetch(`${API_BASE_URL}/profile/team/members`);
  if (!response.ok) throw new Error('Failed to fetch team members');
  return await response.json();
};

export const applyForTeam = async (applicationData: TeamApplication): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/profile/team/apply`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(applicationData),
  });
  if (!response.ok) throw new Error('Failed to apply for team');
  return await response.text();
};

export const getAppliedTeams = async (myUserName: string): Promise<TeamApplication[]> => {
  const response = await fetch(`${API_BASE_URL}/profile/team/applied/${myUserName}`);
  if (!response.ok) return [];
  return await response.json();
};

