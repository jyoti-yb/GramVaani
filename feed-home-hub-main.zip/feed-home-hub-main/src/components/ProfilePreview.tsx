import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { getProfile, type Profile } from "@/lib/api";
import { Github, Linkedin, Mail, Phone, User } from "lucide-react";

interface ProfilePreviewProps {
  username: string;
  children: React.ReactNode;
  asDialog?: boolean;
}

export const ProfilePreview = ({ username, children, asDialog = false }: ProfilePreviewProps) => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (open && !profile) {
      loadProfile();
    }
  }, [open]);

  const loadProfile = async () => {
    setIsLoading(true);
    try {
      const data = await getProfile(username);
      setProfile(data);
    } catch (error) {
      console.error("Failed to load profile:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const ProfileContent = () => {
    if (isLoading) {
      return (
        <div className="p-4 space-y-3">
          <div className="animate-pulse">
            <div className="h-16 w-16 bg-muted rounded-full mb-3"></div>
            <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
            <div className="h-3 bg-muted rounded w-full"></div>
          </div>
        </div>
      );
    }

    if (!profile) {
      return (
        <div className="p-4 text-center text-muted-foreground">
          <User className="mx-auto mb-2" size={32} />
          <p>Profile not found</p>
        </div>
      );
    }

    return (
      <div className="p-4 space-y-4">
        <div className="flex items-start gap-3">
          <Avatar className="h-16 w-16 border-2 border-primary/20">
            <AvatarFallback className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground text-xl">
              {profile.fullName?.split(' ').map(n => n[0]).join('') || username[0].toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h3 className="font-semibold text-lg">{profile.fullName}</h3>
            <p className="text-sm text-muted-foreground">@{username}</p>
            {profile.branch && (
              <Badge variant="outline" className="mt-1">
                {profile.branch}
              </Badge>
            )}
          </div>
        </div>

        {profile.bio && (
          <p className="text-sm text-muted-foreground">{profile.bio}</p>
        )}

        <div className="space-y-2">
          {profile.phone && (
            <div className="flex items-center gap-2 text-sm">
              <Phone size={14} className="text-primary" />
              <a href={`tel:${profile.phone}`} className="hover:underline">
                {profile.phone}
              </a>
            </div>
          )}
          {profile.githubLink && (
            <div className="flex items-center gap-2 text-sm">
              <Github size={14} className="text-primary" />
              <a
                href={profile.githubLink}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:underline truncate"
              >
                GitHub Profile
              </a>
            </div>
          )}
          {profile.linkedinLink && (
            <div className="flex items-center gap-2 text-sm">
              <Linkedin size={14} className="text-primary" />
              <a
                href={profile.linkedinLink}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:underline truncate"
              >
                LinkedIn Profile
              </a>
            </div>
          )}
        </div>

        {profile.skills && profile.skills.length > 0 && (
          <div>
            <p className="text-xs font-semibold mb-2 text-muted-foreground">Skills</p>
            <div className="flex flex-wrap gap-1">
              {profile.skills.slice(0, 5).map((skill, idx) => (
                <Badge key={idx} variant="secondary" className="text-xs">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  if (asDialog) {
    return (
      <>
        <span onClick={() => setOpen(true)} className="cursor-pointer">
          {children}
        </span>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>User Profile</DialogTitle>
            </DialogHeader>
            <ProfileContent />
          </DialogContent>
        </Dialog>
      </>
    );
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <span className="cursor-pointer hover:underline">{children}</span>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="start">
        <ProfileContent />
      </PopoverContent>
    </Popover>
  );
};
