import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Trash2, Clock, Loader2, Send } from "lucide-react";
import { useState, useEffect } from "react";
import { getFeedComments, addFeedComment, deleteFeedComment, type FeedComment } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { ProfilePreview } from "./ProfilePreview";

interface FeedCardProps {
  title: string;
  description: string;
  username: string;
  department: string;
  onDelete: () => void;
  feedId: number;
  userFullName?: string;
  userBranch?: string;
  createdAt?: string;
  onEdit?: () => void;
}

const FeedCard = ({ 
  title, 
  description, 
  username, 
  department, 
  onDelete,
  feedId,
  userFullName,
  userBranch,
  createdAt,
  onEdit
}: FeedCardProps) => {
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<FeedComment[]>([]);
  const [newComment, setNewComment] = useState("");
  const [isLoadingComments, setIsLoadingComments] = useState(false);
  const [isAddingComment, setIsAddingComment] = useState(false);
  const { username: currentUsername } = useAuth();

  useEffect(() => {
    if (showComments && feedId) {
      loadComments();
    }
  }, [showComments, feedId]);

  const loadComments = async () => {
    if (!feedId) return;
    setIsLoadingComments(true);
    try {
      const data = await getFeedComments(feedId);
      setComments(data);
    } catch (error) {
      toast({ title: "Error", description: "Failed to load comments", variant: "destructive" });
    } finally {
      setIsLoadingComments(false);
    }
  };

  const handleAddComment = async () => {
    if (!newComment.trim() || !feedId || !currentUsername) return;
    
    setIsAddingComment(true);
    try {
      await addFeedComment({ feedId, comment: newComment.trim(), username: currentUsername });
      setNewComment("");
      await loadComments();
      toast({ title: "Comment added", description: "Your comment has been posted" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to add comment", variant: "destructive" });
    } finally {
      setIsAddingComment(false);
    }
  };

  const handleDeleteComment = async (commentNum: number, commentUsername?: string) => {
    if (commentUsername !== currentUsername) return;
    if (!confirm("Delete this comment?")) return;
    
    try {
      await deleteFeedComment(commentNum);
      await loadComments();
      toast({ title: "Comment deleted", description: "Comment has been removed" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete comment", variant: "destructive" });
    }
  };

  return (
    <Card className="shadow-soft hover:shadow-medium transition-all duration-200">
      <CardHeader className="pb-3 bg-gradient-to-br from-primary/5 to-primary/10">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3 flex-1">
            <Avatar className="h-10 w-10">
              <AvatarFallback className="bg-primary text-primary-foreground">
                {(userFullName || username).split(' ').map(n => n[0]).join('').toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <CardTitle className="text-lg font-bold">{title}</CardTitle>
              <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                <ProfilePreview username={username}>
                  <span className="font-medium hover:text-primary cursor-pointer transition-colors">
                    {userFullName || username}
                  </span>
                </ProfilePreview>
                {userBranch && <span>• {userBranch}</span>}
              </div>
            </div>
          </div>
          <Badge className="bg-primary/10 text-primary hover:bg-primary/20">{department}</Badge>
        </div>
      </CardHeader>

      <CardContent className="pt-4">
        <p className="text-sm text-foreground leading-relaxed">{description}</p>
      </CardContent>

      <CardFooter className="flex justify-between items-center px-6 py-3 bg-muted/30 border-t">
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setShowComments(!showComments)}
            className="gap-2 hover:bg-primary/10"
          >
            <MessageCircle size={16} />
            <span>{comments.length}</span>
          </Button>
          {createdAt && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock size={14} />
              <span>{formatDistanceToNow(new Date(createdAt), { addSuffix: true })}</span>
            </div>
          )}
        </div>
        {currentUsername === username && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onDelete}
            className="text-destructive hover:text-destructive hover:bg-destructive/10"
          >
            <Trash2 size={16} />
          </Button>
        )}
      </CardFooter>

      {/* Comments Section */}
      {showComments && (
        <div className="px-6 pb-6 pt-3 space-y-3 border-t bg-muted/20">
          {isLoadingComments ? (
            <div className="text-center py-4">
              <Loader2 className="w-4 h-4 animate-spin mx-auto text-muted-foreground" />
            </div>
          ) : (
            <>
              {comments.length > 0 && (
                <div className="space-y-3 max-h-60 overflow-y-auto">
                  {comments.map((comment) => (
                    <div key={comment.num} className="flex items-start gap-2">
                      <Avatar className="h-7 w-7">
                        <AvatarFallback className="bg-primary/10 text-primary text-xs">
                          {comment.username?.substring(0, 2).toUpperCase() || "??"}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 bg-background rounded-lg p-3 shadow-sm border">
                        {comment.username ? (
                          <ProfilePreview username={comment.username}>
                            <p className="text-xs font-semibold text-primary mb-1 hover:underline cursor-pointer">
                              {comment.username}
                            </p>
                          </ProfilePreview>
                        ) : (
                          <p className="text-xs font-semibold text-muted-foreground mb-1">Anonymous</p>
                        )}
                        <p className="text-sm text-foreground">{comment.comment}</p>
                      </div>
                      {currentUsername && comment.username === currentUsername && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 p-0 opacity-0 hover:opacity-100 transition-opacity text-destructive hover:bg-destructive/10"
                          onClick={() => handleDeleteComment(comment.num!, comment.username)}
                        >
                          <Trash2 size={14} />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              )}
              
              <div className="flex items-center gap-2 pt-2">
                <Input
                  placeholder="Write a comment..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddComment()}
                  className="flex-1"
                />
                <Button 
                  size="sm" 
                  onClick={handleAddComment}
                  disabled={!newComment.trim() || isAddingComment}
                  className="bg-gradient-primary text-white"
                >
                  {isAddingComment ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send size={16} />}
                </Button>
              </div>
            </>
          )}
        </div>
      )}
    </Card>
  );
};

export default FeedCard;
