import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { getStoredUsername, login as apiLogin, signup as apiSignup, logout as apiLogout } from '@/lib/api';

interface AuthContextType {
  username: string | null;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<string>;
  signup: (userData: { username: string; password: string; email: string; fullName: string }) => Promise<string>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [username, setUsername] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedUsername = getStoredUsername();
    setUsername(storedUsername);
    setIsLoading(false);
  }, []);

  const login = async (loginUsername: string, password: string): Promise<string> => {
    const result = await apiLogin({ username: loginUsername, password });
    if (result.includes('successful')) {
      setUsername(loginUsername);
    }
    return result;
  };

  const signup = async (userData: { username: string; password: string; email: string; fullName: string }): Promise<string> => {
    return await apiSignup(userData);
  };

  const logout = () => {
    apiLogout();
    setUsername(null);
  };

  const value = {
    username,
    isAuthenticated: !!username,
    login,
    signup,
    logout,
    isLoading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};